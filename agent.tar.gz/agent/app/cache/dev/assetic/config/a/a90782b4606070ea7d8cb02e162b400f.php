<?php

// :blog:_delete_post_confirmation.html.twig
return array (
);
