<?php

// :blog:post_show.html.twig
return array (
);
