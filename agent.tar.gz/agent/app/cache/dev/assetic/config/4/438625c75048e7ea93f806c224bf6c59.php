<?php

// :admin/blog:new.html.twig
return array (
);
