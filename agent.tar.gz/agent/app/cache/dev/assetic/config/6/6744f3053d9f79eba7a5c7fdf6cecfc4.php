<?php

// :blog:index.html.twig
return array (
);
