<?php

// :admin/blog:edit.html.twig
return array (
);
