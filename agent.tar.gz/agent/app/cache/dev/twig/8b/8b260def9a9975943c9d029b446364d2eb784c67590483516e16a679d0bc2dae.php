<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_d191f3ab952f0e226fbb6794aaabf882e18612e5927cbad76f4c88e2d644e162 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6a7fb99c8f8571ff925911ac5962a006a8f179ffe00f609f12bb6a017a07ab3 = $this->env->getExtension("native_profiler");
        $__internal_f6a7fb99c8f8571ff925911ac5962a006a8f179ffe00f609f12bb6a017a07ab3->enter($__internal_f6a7fb99c8f8571ff925911ac5962a006a8f179ffe00f609f12bb6a017a07ab3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_f6a7fb99c8f8571ff925911ac5962a006a8f179ffe00f609f12bb6a017a07ab3->leave($__internal_f6a7fb99c8f8571ff925911ac5962a006a8f179ffe00f609f12bb6a017a07ab3_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_2bf1a0f846ff2bffc8f3f826e44c27d80688401d3d27c144ed8d285ec9c91c40 = $this->env->getExtension("native_profiler");
        $__internal_2bf1a0f846ff2bffc8f3f826e44c27d80688401d3d27c144ed8d285ec9c91c40->enter($__internal_2bf1a0f846ff2bffc8f3f826e44c27d80688401d3d27c144ed8d285ec9c91c40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_2bf1a0f846ff2bffc8f3f826e44c27d80688401d3d27c144ed8d285ec9c91c40->leave($__internal_2bf1a0f846ff2bffc8f3f826e44c27d80688401d3d27c144ed8d285ec9c91c40_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
