<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_f2f4318c848c82661f1a3878db5b4c3441ed9a0d7c952bd50cf9e54e71e107c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f23158a85fd796369861c43545ee8eab3aa4a73d40e7336b3fb050ef774ba779 = $this->env->getExtension("native_profiler");
        $__internal_f23158a85fd796369861c43545ee8eab3aa4a73d40e7336b3fb050ef774ba779->enter($__internal_f23158a85fd796369861c43545ee8eab3aa4a73d40e7336b3fb050ef774ba779_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f23158a85fd796369861c43545ee8eab3aa4a73d40e7336b3fb050ef774ba779->leave($__internal_f23158a85fd796369861c43545ee8eab3aa4a73d40e7336b3fb050ef774ba779_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_29974ea2e8f7bf1c3df0690f5b3e3493a707ee3d68eb34d65ee48da5fbaf9221 = $this->env->getExtension("native_profiler");
        $__internal_29974ea2e8f7bf1c3df0690f5b3e3493a707ee3d68eb34d65ee48da5fbaf9221->enter($__internal_29974ea2e8f7bf1c3df0690f5b3e3493a707ee3d68eb34d65ee48da5fbaf9221_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_29974ea2e8f7bf1c3df0690f5b3e3493a707ee3d68eb34d65ee48da5fbaf9221->leave($__internal_29974ea2e8f7bf1c3df0690f5b3e3493a707ee3d68eb34d65ee48da5fbaf9221_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_263c6d27e510f9e75cf0aa2ab02ac93d2ae1e70166f92e558e916561a17d0447 = $this->env->getExtension("native_profiler");
        $__internal_263c6d27e510f9e75cf0aa2ab02ac93d2ae1e70166f92e558e916561a17d0447->enter($__internal_263c6d27e510f9e75cf0aa2ab02ac93d2ae1e70166f92e558e916561a17d0447_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_263c6d27e510f9e75cf0aa2ab02ac93d2ae1e70166f92e558e916561a17d0447->leave($__internal_263c6d27e510f9e75cf0aa2ab02ac93d2ae1e70166f92e558e916561a17d0447_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'TwigBundle::layout.html.twig' %}*/
/* */
/* {% block title 'Redirection Intercepted' %}*/
/* */
/* {% block body %}*/
/*     <div class="sf-reset">*/
/*         <div class="block-exception">*/
/*             <h1>This request redirects to <a href="{{ location }}">{{ location }}</a>.</h1>*/
/* */
/*             <p>*/
/*                 <small>*/
/*                     The redirect was intercepted by the web debug toolbar to help debugging.*/
/*                     For more information, see the "intercept-redirects" option of the Profiler.*/
/*                 </small>*/
/*             </p>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
