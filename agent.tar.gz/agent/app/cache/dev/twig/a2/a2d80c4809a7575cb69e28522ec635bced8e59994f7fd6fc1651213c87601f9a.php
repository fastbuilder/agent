<?php

/* @CodeExplorer/source_code.html.twig */
class __TwigTemplate_16602b73c9c72fe574ac85d35a1ade72c4d995c260fa23b3ff6fc435c5f2a0f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0326c0ecf17eb88c422c67c68939c486ff0d7a9281d54c6fc91d74be8f962fe3 = $this->env->getExtension("native_profiler");
        $__internal_0326c0ecf17eb88c422c67c68939c486ff0d7a9281d54c6fc91d74be8f962fe3->enter($__internal_0326c0ecf17eb88c422c67c68939c486ff0d7a9281d54c6fc91d74be8f962fe3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@CodeExplorer/source_code.html.twig"));

        // line 1
        echo "<div class=\"section source-code\">
    ";
        // line 3
        echo "      ";
        // line 4
        echo "    ";
        // line 5
        echo "
    <div class=\"modal fade\" id=\"sourceCodeModal\" tabindex=\"-1\">
        <div class=\"modal-dialog modal-lg\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                        <span aria-hidden=\"true\">&times;</span>
                    </button>
                    <h4 class=\"modal-title\"><i class=\"fa fa-code\"></i> ";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("title.source_code"), "html", null, true);
        echo "</h4>
                </div>

                <div class=\"modal-body\">
                    ";
        // line 17
        if ((isset($context["controller"]) ? $context["controller"] : $this->getContext($context, "controller"))) {
            // line 18
            echo "                        <h3>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("title.controller_code"), "html", null, true);
            echo "<small class=\"pull-right\">";
            echo $this->env->getExtension('code')->formatFile($this->getAttribute((isset($context["controller"]) ? $context["controller"] : $this->getContext($context, "controller")), "file_path", array()), $this->getAttribute((isset($context["controller"]) ? $context["controller"] : $this->getContext($context, "controller")), "starting_line", array()));
            echo "</small></h3>
                        <pre><code class=\"php\">";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["controller"]) ? $context["controller"] : $this->getContext($context, "controller")), "source_code", array()), "html", null, true);
            echo "</code></pre>
                    ";
        } else {
            // line 21
            echo "                        <h3>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("title.controller_code"), "html", null, true);
            echo "</h3>
                        <pre><code>";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("not_available"), "html", null, true);
            echo "</code></pre>
                    ";
        }
        // line 24
        echo "
                    <h3>";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("title.twig_template_code"), "html", null, true);
        echo "<small class=\"pull-right\">";
        echo $this->env->getExtension('code')->formatFile($this->getAttribute((isset($context["template"]) ? $context["template"] : $this->getContext($context, "template")), "file_path", array()), $this->getAttribute((isset($context["template"]) ? $context["template"] : $this->getContext($context, "template")), "starting_line", array()));
        echo "</small></h3>
                    <pre><code class=\"twig\">";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["template"]) ? $context["template"] : $this->getContext($context, "template")), "source_code", array()), "html", null, true);
        echo "</code></pre>
                </div>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_0326c0ecf17eb88c422c67c68939c486ff0d7a9281d54c6fc91d74be8f962fe3->leave($__internal_0326c0ecf17eb88c422c67c68939c486ff0d7a9281d54c6fc91d74be8f962fe3_prof);

    }

    public function getTemplateName()
    {
        return "@CodeExplorer/source_code.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 26,  73 => 25,  70 => 24,  65 => 22,  60 => 21,  55 => 19,  48 => 18,  46 => 17,  39 => 13,  29 => 5,  27 => 4,  25 => 3,  22 => 1,);
    }
}
/* <div class="section source-code">*/
/*     {#<button type="button" class="btn btn-default btn-lg btn-block" data-toggle="modal" data-target="#sourceCodeModal">#}*/
/*       {#<i class="fa fa-cogs"></i> {{ 'action.show_code'|trans }}#}*/
/*     {#</button>#}*/
/* */
/*     <div class="modal fade" id="sourceCodeModal" tabindex="-1">*/
/*         <div class="modal-dialog modal-lg">*/
/*             <div class="modal-content">*/
/*                 <div class="modal-header">*/
/*                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">*/
/*                         <span aria-hidden="true">&times;</span>*/
/*                     </button>*/
/*                     <h4 class="modal-title"><i class="fa fa-code"></i> {{ 'title.source_code'|trans }}</h4>*/
/*                 </div>*/
/* */
/*                 <div class="modal-body">*/
/*                     {% if controller %}*/
/*                         <h3>{{ 'title.controller_code'|trans }}<small class="pull-right">{{ controller.file_path|format_file(controller.starting_line) }}</small></h3>*/
/*                         <pre><code class="php">{{ controller.source_code }}</code></pre>*/
/*                     {% else %}*/
/*                         <h3>{{ 'title.controller_code'|trans }}</h3>*/
/*                         <pre><code>{{ 'not_available'|trans }}</code></pre>*/
/*                     {% endif %}*/
/* */
/*                     <h3>{{ 'title.twig_template_code'|trans }}<small class="pull-right">{{ template.file_path|format_file(template.starting_line) }}</small></h3>*/
/*                     <pre><code class="twig">{{ template.source_code }}</code></pre>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* </div>*/
/* */
