<?php

/* TwigBundle:Exception:error500.html.twig */
class __TwigTemplate_6c8430aaceac6ba2534fec356d3883763f057718f7c963481e621545cb0c572a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error500.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a4877d41f3e610a218a44ae5674f1bc3a4fe8dc626c89f587a7aee300fbbadc = $this->env->getExtension("native_profiler");
        $__internal_9a4877d41f3e610a218a44ae5674f1bc3a4fe8dc626c89f587a7aee300fbbadc->enter($__internal_9a4877d41f3e610a218a44ae5674f1bc3a4fe8dc626c89f587a7aee300fbbadc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error500.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9a4877d41f3e610a218a44ae5674f1bc3a4fe8dc626c89f587a7aee300fbbadc->leave($__internal_9a4877d41f3e610a218a44ae5674f1bc3a4fe8dc626c89f587a7aee300fbbadc_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_1ca2b3b4bb8bf06db2f95d046698f462db1ddc5a6cad9a8166e195c80841b905 = $this->env->getExtension("native_profiler");
        $__internal_1ca2b3b4bb8bf06db2f95d046698f462db1ddc5a6cad9a8166e195c80841b905->enter($__internal_1ca2b3b4bb8bf06db2f95d046698f462db1ddc5a6cad9a8166e195c80841b905_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_1ca2b3b4bb8bf06db2f95d046698f462db1ddc5a6cad9a8166e195c80841b905->leave($__internal_1ca2b3b4bb8bf06db2f95d046698f462db1ddc5a6cad9a8166e195c80841b905_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_69df0ea0a497ed9d5fd4aa7bd42fbe3db253101985a5828979b8b9c4ac44fe1d = $this->env->getExtension("native_profiler");
        $__internal_69df0ea0a497ed9d5fd4aa7bd42fbe3db253101985a5828979b8b9c4ac44fe1d->enter($__internal_69df0ea0a497ed9d5fd4aa7bd42fbe3db253101985a5828979b8b9c4ac44fe1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">Error 500</h1>

    <p class=\"lead\">
        There was an internal server error.
    </p>
    <p>
        Try loading this page again in some minutes or
        <a href=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("blog_index");
        echo "\">go back to the homepage</a>.
    </p>
";
        
        $__internal_69df0ea0a497ed9d5fd4aa7bd42fbe3db253101985a5828979b8b9c4ac44fe1d->leave($__internal_69df0ea0a497ed9d5fd4aa7bd42fbe3db253101985a5828979b8b9c4ac44fe1d_prof);

    }

    // line 27
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_f78c2609385419237d714aa5e1b7dbce8595869e9d40fb13bac308fa7014f601 = $this->env->getExtension("native_profiler");
        $__internal_f78c2609385419237d714aa5e1b7dbce8595869e9d40fb13bac308fa7014f601->enter($__internal_f78c2609385419237d714aa5e1b7dbce8595869e9d40fb13bac308fa7014f601_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 28
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 30
        echo $this->env->getExtension('code_explorer_source_code')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_f78c2609385419237d714aa5e1b7dbce8595869e9d40fb13bac308fa7014f601->leave($__internal_f78c2609385419237d714aa5e1b7dbce8595869e9d40fb13bac308fa7014f601_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error500.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 30,  79 => 28,  73 => 27,  63 => 23,  54 => 16,  48 => 15,  36 => 13,  11 => 11,);
    }
}
/* {#*/
/*     This template is used to render errors of type HTTP 500 (Internal Server Error)*/
/* */
/*     This is the simplest way to customize error pages in Symfony applications.*/
/*     In case you need it, you can also hook into the internal exception handling*/
/*     made by Symfony. This allows you to perform advanced tasks and even recover*/
/*     your application from some errors.*/
/*     See http://symfony.com/doc/current/cookbook/controller/error_pages.html*/
/* #}*/
/* */
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body_id 'error' %}*/
/* */
/* {% block main %}*/
/*     <h1 class="text-danger">Error 500</h1>*/
/* */
/*     <p class="lead">*/
/*         There was an internal server error.*/
/*     </p>*/
/*     <p>*/
/*         Try loading this page again in some minutes or*/
/*         <a href="{{ path('blog_index') }}">go back to the homepage</a>.*/
/*     </p>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/*     {{ parent() }}*/
/* */
/*     {{ show_source_code(_self) }}*/
/* {% endblock %}*/
/* */
