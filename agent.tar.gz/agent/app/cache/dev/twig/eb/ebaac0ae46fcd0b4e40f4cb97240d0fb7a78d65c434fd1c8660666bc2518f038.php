<?php

/* form/fields.html.twig */
class __TwigTemplate_c18c92d7a2e3acd2b52ed36c3422fc72203f18bdb3403153e37419a8291c1561 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'app_datetimepicker_widget' => array($this, 'block_app_datetimepicker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3a791a7b3e30b2cd53eae29b17c3c51ebe770645aee5dc14cefadd90761c4566 = $this->env->getExtension("native_profiler");
        $__internal_3a791a7b3e30b2cd53eae29b17c3c51ebe770645aee5dc14cefadd90761c4566->enter($__internal_3a791a7b3e30b2cd53eae29b17c3c51ebe770645aee5dc14cefadd90761c4566_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        // line 7
        echo "
";
        // line 8
        $this->displayBlock('app_datetimepicker_widget', $context, $blocks);
        
        $__internal_3a791a7b3e30b2cd53eae29b17c3c51ebe770645aee5dc14cefadd90761c4566->leave($__internal_3a791a7b3e30b2cd53eae29b17c3c51ebe770645aee5dc14cefadd90761c4566_prof);

    }

    public function block_app_datetimepicker_widget($context, array $blocks = array())
    {
        $__internal_89b268f7d392eb2b02d1981ecf7f6dfce17eb4ed8192ad51466747862263eac4 = $this->env->getExtension("native_profiler");
        $__internal_89b268f7d392eb2b02d1981ecf7f6dfce17eb4ed8192ad51466747862263eac4->enter($__internal_89b268f7d392eb2b02d1981ecf7f6dfce17eb4ed8192ad51466747862263eac4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "app_datetimepicker_widget"));

        // line 9
        echo "    ";
        ob_start();
        // line 10
        echo "        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            ";
        // line 11
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
            <span class=\"input-group-addon\">
                <span class=\"fa fa-calendar\"></span>
            </span>
        </div>
    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_89b268f7d392eb2b02d1981ecf7f6dfce17eb4ed8192ad51466747862263eac4->leave($__internal_89b268f7d392eb2b02d1981ecf7f6dfce17eb4ed8192ad51466747862263eac4_prof);

    }

    public function getTemplateName()
    {
        return "form/fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  44 => 11,  41 => 10,  38 => 9,  26 => 8,  23 => 7,);
    }
}
/* {#*/
/*    Each field type is rendered by a template fragment, which is determined*/
/*    by the value of your getName() method and the suffix _widget.*/
/* */
/*    See http://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field*/
/* #}*/
/* */
/* {% block app_datetimepicker_widget %}*/
/*     {% spaceless %}*/
/*         <div class="input-group date" data-toggle="datetimepicker">*/
/*             {{ block('datetime_widget') }}*/
/*             <span class="input-group-addon">*/
/*                 <span class="fa fa-calendar"></span>*/
/*             </span>*/
/*         </div>*/
/*     {% endspaceless %}*/
/* {% endblock %}*/
/* */
