<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_79c4a6bd8ba13bb2f0929ca024fb3fbcb61b844a410757543d6582d7f3977e35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9643d048c4f46eff4cb0311cffccfb6e876ce2893921b00d48f56c57a23c5e88 = $this->env->getExtension("native_profiler");
        $__internal_9643d048c4f46eff4cb0311cffccfb6e876ce2893921b00d48f56c57a23c5e88->enter($__internal_9643d048c4f46eff4cb0311cffccfb6e876ce2893921b00d48f56c57a23c5e88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_9643d048c4f46eff4cb0311cffccfb6e876ce2893921b00d48f56c57a23c5e88->leave($__internal_9643d048c4f46eff4cb0311cffccfb6e876ce2893921b00d48f56c57a23c5e88_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:exception.xml.twig' with { 'exception': exception } %}*/
/* */
