<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_ccf9a50ad365da394f3206e28db4193168e7c15d108889e8f9c06fb2269bd601 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e6c15e4960cea2c72497f85bed4b3106b3e69c69025676601263450b59a77c1 = $this->env->getExtension("native_profiler");
        $__internal_9e6c15e4960cea2c72497f85bed4b3106b3e69c69025676601263450b59a77c1->enter($__internal_9e6c15e4960cea2c72497f85bed4b3106b3e69c69025676601263450b59a77c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_9e6c15e4960cea2c72497f85bed4b3106b3e69c69025676601263450b59a77c1->leave($__internal_9e6c15e4960cea2c72497f85bed4b3106b3e69c69025676601263450b59a77c1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
