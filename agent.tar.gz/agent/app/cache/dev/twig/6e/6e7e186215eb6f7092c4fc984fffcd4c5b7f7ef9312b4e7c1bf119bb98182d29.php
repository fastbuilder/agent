<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_ac6544a26f9e87c1dbb77c3ab5479e8cee75afc85e23497da6d61a90135fbd9c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7aef1643b2dedf69c48b30f71cace2e05be3303d68a067a60b22ef974b8812c6 = $this->env->getExtension("native_profiler");
        $__internal_7aef1643b2dedf69c48b30f71cace2e05be3303d68a067a60b22ef974b8812c6->enter($__internal_7aef1643b2dedf69c48b30f71cace2e05be3303d68a067a60b22ef974b8812c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("TwigBundle:Exception:exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_7aef1643b2dedf69c48b30f71cace2e05be3303d68a067a60b22ef974b8812c6->leave($__internal_7aef1643b2dedf69c48b30f71cace2e05be3303d68a067a60b22ef974b8812c6_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include 'TwigBundle:Exception:exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
