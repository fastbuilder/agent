<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_280eb15aa28b234b387c71e75f98b5b3d35da67d8202f0d2581b3277cd221e34 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e71f01cbab636e49b41bc9d5b7b3a84285ced0cf16357e6cb7a039770df72dc0 = $this->env->getExtension("native_profiler");
        $__internal_e71f01cbab636e49b41bc9d5b7b3a84285ced0cf16357e6cb7a039770df72dc0->enter($__internal_e71f01cbab636e49b41bc9d5b7b3a84285ced0cf16357e6cb7a039770df72dc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_e71f01cbab636e49b41bc9d5b7b3a84285ced0cf16357e6cb7a039770df72dc0->leave($__internal_e71f01cbab636e49b41bc9d5b7b3a84285ced0cf16357e6cb7a039770df72dc0_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:error.xml.twig' %}*/
/* */
