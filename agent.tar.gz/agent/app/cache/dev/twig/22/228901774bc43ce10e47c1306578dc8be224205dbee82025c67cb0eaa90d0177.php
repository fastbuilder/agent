<?php

/* security/login.html.twig */
class __TwigTemplate_b896c495a56d2d10676e30918b4bf2c5aa44cc5fa7b7511f5d922a2ffbb509a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84dd19bff5caebf5284d9906bf73f55a5970aee3d49fd1569f4790793db5b825 = $this->env->getExtension("native_profiler");
        $__internal_84dd19bff5caebf5284d9906bf73f55a5970aee3d49fd1569f4790793db5b825->enter($__internal_84dd19bff5caebf5284d9906bf73f55a5970aee3d49fd1569f4790793db5b825_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_84dd19bff5caebf5284d9906bf73f55a5970aee3d49fd1569f4790793db5b825->leave($__internal_84dd19bff5caebf5284d9906bf73f55a5970aee3d49fd1569f4790793db5b825_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_972882d230cef92c06bbdf4a84bbdd3d2e3fd1e9cebb5db818abae15ba24ffb7 = $this->env->getExtension("native_profiler");
        $__internal_972882d230cef92c06bbdf4a84bbdd3d2e3fd1e9cebb5db818abae15ba24ffb7->enter($__internal_972882d230cef92c06bbdf4a84bbdd3d2e3fd1e9cebb5db818abae15ba24ffb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "login";
        
        $__internal_972882d230cef92c06bbdf4a84bbdd3d2e3fd1e9cebb5db818abae15ba24ffb7->leave($__internal_972882d230cef92c06bbdf4a84bbdd3d2e3fd1e9cebb5db818abae15ba24ffb7_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_8712f3958aea00f13ac5f3935cd4639b7169e787bb5a23fc0598fa80b08140ea = $this->env->getExtension("native_profiler");
        $__internal_8712f3958aea00f13ac5f3935cd4639b7169e787bb5a23fc0598fa80b08140ea->enter($__internal_8712f3958aea00f13ac5f3935cd4639b7169e787bb5a23fc0598fa80b08140ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    ";
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 7
            echo "        <div class=\"alert alert-danger\">
            ";
            // line 8
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 11
        echo "
    <div class=\"row\">
        <div class=\"col-sm-5\">
            <div class=\"well\">
                <form action=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("security_login_check");
        echo "\" method=\"post\">
                    <fieldset>
                        <legend><i class=\"fa fa-lock\"></i> ";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("title.login"), "html", null, true);
        echo "</legend>
                        <div class=\"form-group\">
                            <label for=\"username\">";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("label.username"), "html", null, true);
        echo "</label>
                            <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" class=\"form-control\"/>
                        </div>
                        <div class=\"form-group\">
                            <label for=\"password\">";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("label.password"), "html", null, true);
        echo "</label>
                            <input type=\"password\" id=\"password\" name=\"_password\" class=\"form-control\" />
                        </div>
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('form')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"/>
                        <button type=\"submit\" class=\"btn btn-primary\">
                            <i class=\"fa fa-sign-in\"></i> ";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("action.sign_in"), "html", null, true);
        echo "
                        </button>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
";
        
        $__internal_8712f3958aea00f13ac5f3935cd4639b7169e787bb5a23fc0598fa80b08140ea->leave($__internal_8712f3958aea00f13ac5f3935cd4639b7169e787bb5a23fc0598fa80b08140ea_prof);

    }

    // line 36
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_0c7654fe02cd2ec0c244b88553e0db99e9028187610f17a1db7a471f4a3bfed0 = $this->env->getExtension("native_profiler");
        $__internal_0c7654fe02cd2ec0c244b88553e0db99e9028187610f17a1db7a471f4a3bfed0->enter($__internal_0c7654fe02cd2ec0c244b88553e0db99e9028187610f17a1db7a471f4a3bfed0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 37
        echo "
    ";
        // line 38
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 40
        echo $this->env->getExtension('code_explorer_source_code')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_0c7654fe02cd2ec0c244b88553e0db99e9028187610f17a1db7a471f4a3bfed0->leave($__internal_0c7654fe02cd2ec0c244b88553e0db99e9028187610f17a1db7a471f4a3bfed0_prof);

    }

    // line 43
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9da0025defc34737479631bede52ea06bcd87df03bacbc56f0cebadd666f1342 = $this->env->getExtension("native_profiler");
        $__internal_9da0025defc34737479631bede52ea06bcd87df03bacbc56f0cebadd666f1342->enter($__internal_9da0025defc34737479631bede52ea06bcd87df03bacbc56f0cebadd666f1342_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 44
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

    <script>
        \$(document).ready(function() {
            \$('#username').val('');
            \$('#password').val('');
        });
    </script>
";
        
        $__internal_9da0025defc34737479631bede52ea06bcd87df03bacbc56f0cebadd666f1342->leave($__internal_9da0025defc34737479631bede52ea06bcd87df03bacbc56f0cebadd666f1342_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  148 => 44,  142 => 43,  133 => 40,  128 => 38,  125 => 37,  119 => 36,  104 => 28,  99 => 26,  93 => 23,  87 => 20,  83 => 19,  78 => 17,  73 => 15,  67 => 11,  61 => 8,  58 => 7,  55 => 6,  49 => 5,  37 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body_id 'login' %}*/
/* */
/* {% block main %}*/
/*     {% if error %}*/
/*         <div class="alert alert-danger">*/
/*             {{ error.messageKey|trans(error.messageData, 'security') }}*/
/*         </div>*/
/*     {% endif %}*/
/* */
/*     <div class="row">*/
/*         <div class="col-sm-5">*/
/*             <div class="well">*/
/*                 <form action="{{ path('security_login_check') }}" method="post">*/
/*                     <fieldset>*/
/*                         <legend><i class="fa fa-lock"></i> {{ 'title.login'|trans }}</legend>*/
/*                         <div class="form-group">*/
/*                             <label for="username">{{ 'label.username'|trans }}</label>*/
/*                             <input type="text" id="username" name="_username" value="{{ last_username }}" class="form-control"/>*/
/*                         </div>*/
/*                         <div class="form-group">*/
/*                             <label for="password">{{ 'label.password'|trans }}</label>*/
/*                             <input type="password" id="password" name="_password" class="form-control" />*/
/*                         </div>*/
/*                         <input type="hidden" name="_csrf_token" value="{{ csrf_token('authenticate') }}"/>*/
/*                         <button type="submit" class="btn btn-primary">*/
/*                             <i class="fa fa-sign-in"></i> {{ 'action.sign_in'|trans }}*/
/*                         </button>*/
/*                     </fieldset>*/
/*                 </form>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* {% block sidebar %}*/
/* */
/*     {{ parent() }}*/
/* */
/*     {{ show_source_code(_self) }}*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {{ parent() }}*/
/* */
/*     <script>*/
/*         $(document).ready(function() {*/
/*             $('#username').val('');*/
/*             $('#password').val('');*/
/*         });*/
/*     </script>*/
/* {% endblock %}*/
/* */
