<?php

/* SensioDistributionBundle::Configurator/layout.html.twig */
class __TwigTemplate_933f54a87ff465768e705f216b49e3d9c46128ec347ea2a544c6ee94cb673e64 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "SensioDistributionBundle::Configurator/layout.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2b89d85af36afc74c8a660904c6ff4ae46cc0a53dafe4b6d287a3f52d421b590 = $this->env->getExtension("native_profiler");
        $__internal_2b89d85af36afc74c8a660904c6ff4ae46cc0a53dafe4b6d287a3f52d421b590->enter($__internal_2b89d85af36afc74c8a660904c6ff4ae46cc0a53dafe4b6d287a3f52d421b590_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SensioDistributionBundle::Configurator/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2b89d85af36afc74c8a660904c6ff4ae46cc0a53dafe4b6d287a3f52d421b590->leave($__internal_2b89d85af36afc74c8a660904c6ff4ae46cc0a53dafe4b6d287a3f52d421b590_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_f94af9e9b798ad8a05595a63c1bfe37c57698cc4913e798beb7b5473bc48b108 = $this->env->getExtension("native_profiler");
        $__internal_f94af9e9b798ad8a05595a63c1bfe37c57698cc4913e798beb7b5473bc48b108->enter($__internal_f94af9e9b798ad8a05595a63c1bfe37c57698cc4913e798beb7b5473bc48b108_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/sensiodistribution/webconfigurator/css/configurator.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_f94af9e9b798ad8a05595a63c1bfe37c57698cc4913e798beb7b5473bc48b108->leave($__internal_f94af9e9b798ad8a05595a63c1bfe37c57698cc4913e798beb7b5473bc48b108_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_e87c8c0d97292af2a8e78f11fcd9a2461a2c56452d03f470adda480315cd0f53 = $this->env->getExtension("native_profiler");
        $__internal_e87c8c0d97292af2a8e78f11fcd9a2461a2c56452d03f470adda480315cd0f53->enter($__internal_e87c8c0d97292af2a8e78f11fcd9a2461a2c56452d03f470adda480315cd0f53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Web Configurator Bundle";
        
        $__internal_e87c8c0d97292af2a8e78f11fcd9a2461a2c56452d03f470adda480315cd0f53->leave($__internal_e87c8c0d97292af2a8e78f11fcd9a2461a2c56452d03f470adda480315cd0f53_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_ccacdee6e80e00c88c4ab28f699bf400557f325285db3600ea28b65368bee02a = $this->env->getExtension("native_profiler");
        $__internal_ccacdee6e80e00c88c4ab28f699bf400557f325285db3600ea28b65368bee02a->enter($__internal_ccacdee6e80e00c88c4ab28f699bf400557f325285db3600ea28b65368bee02a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <div class=\"block\">
        ";
        // line 11
        $this->displayBlock('content', $context, $blocks);
        // line 12
        echo "    </div>
    <div class=\"version\">Symfony Standard Edition v.";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "</div>
";
        
        $__internal_ccacdee6e80e00c88c4ab28f699bf400557f325285db3600ea28b65368bee02a->leave($__internal_ccacdee6e80e00c88c4ab28f699bf400557f325285db3600ea28b65368bee02a_prof);

    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        $__internal_63b2be5fd4bf059549fa0c1576d31648c034481f6af038e5e264e5a2f9d5a11e = $this->env->getExtension("native_profiler");
        $__internal_63b2be5fd4bf059549fa0c1576d31648c034481f6af038e5e264e5a2f9d5a11e->enter($__internal_63b2be5fd4bf059549fa0c1576d31648c034481f6af038e5e264e5a2f9d5a11e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_63b2be5fd4bf059549fa0c1576d31648c034481f6af038e5e264e5a2f9d5a11e->leave($__internal_63b2be5fd4bf059549fa0c1576d31648c034481f6af038e5e264e5a2f9d5a11e_prof);

    }

    public function getTemplateName()
    {
        return "SensioDistributionBundle::Configurator/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 11,  79 => 13,  76 => 12,  74 => 11,  71 => 10,  65 => 9,  53 => 7,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends "TwigBundle::layout.html.twig" %}*/
/* */
/* {% block head %}*/
/*     <link rel="stylesheet" href="{{ asset('bundles/sensiodistribution/webconfigurator/css/configurator.css') }}" />*/
/* {% endblock %}*/
/* */
/* {% block title 'Web Configurator Bundle' %}*/
/* */
/* {% block body %}*/
/*     <div class="block">*/
/*         {% block content %}{% endblock %}*/
/*     </div>*/
/*     <div class="version">Symfony Standard Edition v.{{ version }}</div>*/
/* {% endblock %}*/
/* */
