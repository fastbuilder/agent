<?php

/* land_base.html.twig */
class __TwigTemplate_d7e92aea38da9eb208c7e3d9ee8bed51f167b56d2919e5c6b1425e4776841710 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'header' => array($this, 'block_header'),
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_73547a82419c76d5ea03ae393fdf1d71c803a90f2063e2f80f3eb40497a71d99 = $this->env->getExtension("native_profiler");
        $__internal_73547a82419c76d5ea03ae393fdf1d71c803a90f2063e2f80f3eb40497a71d99->enter($__internal_73547a82419c76d5ea03ae393fdf1d71c803a90f2063e2f80f3eb40497a71d99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "land_base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>";
        // line 10
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 27
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>

<body>
";
        // line 31
        $this->displayBlock('header', $context, $blocks);
        // line 95
        echo "
";
        // line 96
        $this->displayBlock('body', $context, $blocks);
        // line 105
        echo "

";
        // line 107
        $this->displayBlock('footer', $context, $blocks);
        // line 126
        echo "
";
        // line 127
        $this->displayBlock('javascripts', $context, $blocks);
        // line 142
        echo "</body>
</html>
";
        
        $__internal_73547a82419c76d5ea03ae393fdf1d71c803a90f2063e2f80f3eb40497a71d99->leave($__internal_73547a82419c76d5ea03ae393fdf1d71c803a90f2063e2f80f3eb40497a71d99_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_77d8cddb91813190b7dae92aec8707a818821a8497f8b0905c04806a68ec79a9 = $this->env->getExtension("native_profiler");
        $__internal_77d8cddb91813190b7dae92aec8707a818821a8497f8b0905c04806a68ec79a9->enter($__internal_77d8cddb91813190b7dae92aec8707a818821a8497f8b0905c04806a68ec79a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Secret blog";
        
        $__internal_77d8cddb91813190b7dae92aec8707a818821a8497f8b0905c04806a68ec79a9->leave($__internal_77d8cddb91813190b7dae92aec8707a818821a8497f8b0905c04806a68ec79a9_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_684299a28c6debf257d90b513cdc1af8ccd6de8a45ec65bc96976116f2f6a382 = $this->env->getExtension("native_profiler");
        $__internal_684299a28c6debf257d90b513cdc1af8ccd6de8a45ec65bc96976116f2f6a382->enter($__internal_684299a28c6debf257d90b513cdc1af8ccd6de8a45ec65bc96976116f2f6a382_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        ";
        // line 24
        echo "
        <link rel=\"stylesheet\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/app.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_684299a28c6debf257d90b513cdc1af8ccd6de8a45ec65bc96976116f2f6a382->leave($__internal_684299a28c6debf257d90b513cdc1af8ccd6de8a45ec65bc96976116f2f6a382_prof);

    }

    // line 31
    public function block_header($context, array $blocks = array())
    {
        $__internal_5f8c8312f6ced451bd70c2d142d93147033f0dd8e198891792c98377e7143c44 = $this->env->getExtension("native_profiler");
        $__internal_5f8c8312f6ced451bd70c2d142d93147033f0dd8e198891792c98377e7143c44->enter($__internal_5f8c8312f6ced451bd70c2d142d93147033f0dd8e198891792c98377e7143c44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 32
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a class=\"navbar-brand\" href=\"";
        // line 36
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\">
                        Landing
                    </a>

                    <button type=\"button\" class=\"navbar-toggle\"
                            data-toggle=\"collapse\"
                            data-target=\".navbar-collapse\">
                        <span class=\"sr-only\">Toggle navigation</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">

                        ";
        // line 52
        $this->displayBlock('header_navigation_links', $context, $blocks);
        // line 72
        echo "
                        ";
        // line 73
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 74
            echo "                            <li>
                                <a href=\"";
            // line 75
            echo $this->env->getExtension('routing')->getPath("security_logout");
            echo "\">
                                    <i class=\"fa fa-sign-out\"></i> ";
            // line 76
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.logout"), "html", null, true);
            echo "
                                </a>
                            </li>
                        ";
        }
        // line 80
        echo "
                        <li class=\"dropdown\">
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\"><i class=\"fa fa-globe\"></i> <span class=\"caret\"></span></a>
                            <ul class=\"dropdown-menu locales\" role=\"menu\">
                                ";
        // line 84
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('app.extension')->getLocales());
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 85
            echo "                                    <li ";
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                echo "class=\"active\"";
            }
            echo "><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route", 1 => "blog_index"), "method"), twig_array_merge($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params", 1 => array()), "method"), array("_locale" => $this->getAttribute($context["locale"], "code", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["locale"], "name", array())), "html", null, true);
            echo "</a></li>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 87
        echo "                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
";
        
        $__internal_5f8c8312f6ced451bd70c2d142d93147033f0dd8e198891792c98377e7143c44->leave($__internal_5f8c8312f6ced451bd70c2d142d93147033f0dd8e198891792c98377e7143c44_prof);

    }

    // line 52
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_811c8245e636f98776b82654291138bc68b9a5bbb131fbe6a01d322cf2789846 = $this->env->getExtension("native_profiler");
        $__internal_811c8245e636f98776b82654291138bc68b9a5bbb131fbe6a01d322cf2789846->enter($__internal_811c8245e636f98776b82654291138bc68b9a5bbb131fbe6a01d322cf2789846_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 53
        echo "                            <li>
                                <a href=\"";
        // line 54
        echo $this->env->getExtension('routing')->getPath("blog_index");
        echo "\">
                                    <i class=\"fa fa-home\"></i> ";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.homepage"), "html", null, true);
        echo "
                                </a>
                            </li>

                            ";
        // line 64
        echo "                            ";
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) && $this->env->getExtension('security')->isGranted("ROLE_ADMIN"))) {
            // line 65
            echo "                                <li>
                                    <a href=\"";
            // line 66
            echo $this->env->getExtension('routing')->getPath("admin_post_index");
            echo "\">
                                        <i class=\"fa fa-lock\"></i> ";
            // line 67
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.admin"), "html", null, true);
            echo "
                                    </a>
                                </li>
                            ";
        }
        // line 71
        echo "                        ";
        
        $__internal_811c8245e636f98776b82654291138bc68b9a5bbb131fbe6a01d322cf2789846->leave($__internal_811c8245e636f98776b82654291138bc68b9a5bbb131fbe6a01d322cf2789846_prof);

    }

    // line 96
    public function block_body($context, array $blocks = array())
    {
        $__internal_784fef14cac15ccc4d87cf8c1737403b1813dd8579fc8f2c6e3dc12047d9e86f = $this->env->getExtension("native_profiler");
        $__internal_784fef14cac15ccc4d87cf8c1737403b1813dd8579fc8f2c6e3dc12047d9e86f->enter($__internal_784fef14cac15ccc4d87cf8c1737403b1813dd8579fc8f2c6e3dc12047d9e86f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 97
        echo "    <div class=\"row\">
        <div id=\"main\" class=\"col-sm-9\">
            ";
        // line 99
        echo twig_include($this->env, $context, "default/_flash_messages.html.twig");
        echo "

            ";
        // line 101
        $this->displayBlock('main', $context, $blocks);
        // line 102
        echo "        </div>
    </div>
";
        
        $__internal_784fef14cac15ccc4d87cf8c1737403b1813dd8579fc8f2c6e3dc12047d9e86f->leave($__internal_784fef14cac15ccc4d87cf8c1737403b1813dd8579fc8f2c6e3dc12047d9e86f_prof);

    }

    // line 101
    public function block_main($context, array $blocks = array())
    {
        $__internal_af9dcacc4e440dc9f5a8b8603a7d7f7d1f062881bac7957d16ca8a18c17bf647 = $this->env->getExtension("native_profiler");
        $__internal_af9dcacc4e440dc9f5a8b8603a7d7f7d1f062881bac7957d16ca8a18c17bf647->enter($__internal_af9dcacc4e440dc9f5a8b8603a7d7f7d1f062881bac7957d16ca8a18c17bf647_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_af9dcacc4e440dc9f5a8b8603a7d7f7d1f062881bac7957d16ca8a18c17bf647->leave($__internal_af9dcacc4e440dc9f5a8b8603a7d7f7d1f062881bac7957d16ca8a18c17bf647_prof);

    }

    // line 107
    public function block_footer($context, array $blocks = array())
    {
        $__internal_3ea8462e3dbbb2aba1744965451e9c9698d1a0960dbc2214aca88f723bfb2a54 = $this->env->getExtension("native_profiler");
        $__internal_3ea8462e3dbbb2aba1744965451e9c9698d1a0960dbc2214aca88f723bfb2a54->enter($__internal_3ea8462e3dbbb2aba1744965451e9c9698d1a0960dbc2214aca88f723bfb2a54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 108
        echo "    <footer>
        <div class=\"container\">
            <div class=\"row\">
                <div id=\"footer-copyright\" class=\"col-md-6\">
                    <p>&copy; ";
        // line 112
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo "</p>
                    <p>";
        // line 113
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("mit_license"), "html", null, true);
        echo "</p>
                </div>
                <div id=\"footer-resources\" class=\"col-md-6\">
                    <p>
                        <a href=\"#\"><i class=\"fa fa-twitter\"></i></a>
                        <a href=\"#\"><i class=\"fa fa-facebook\"></i></a>
                        <a href=\"#\"><i class=\"fa fa-rss\"></i></a>
                    </p>
                </div>
            </div>
        </div>
    </footer>
";
        
        $__internal_3ea8462e3dbbb2aba1744965451e9c9698d1a0960dbc2214aca88f723bfb2a54->leave($__internal_3ea8462e3dbbb2aba1744965451e9c9698d1a0960dbc2214aca88f723bfb2a54_prof);

    }

    // line 127
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c76072c90b51956fcb76103bc3ca3789123f15794beca058f3d56cbec3f295c2 = $this->env->getExtension("native_profiler");
        $__internal_c76072c90b51956fcb76103bc3ca3789123f15794beca058f3d56cbec3f295c2->enter($__internal_c76072c90b51956fcb76103bc3ca3789123f15794beca058f3d56cbec3f295c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 128
        echo "    ";
        // line 139
        echo "
    <script src=\"";
        // line 140
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/app.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_c76072c90b51956fcb76103bc3ca3789123f15794beca058f3d56cbec3f295c2->leave($__internal_c76072c90b51956fcb76103bc3ca3789123f15794beca058f3d56cbec3f295c2_prof);

    }

    public function getTemplateName()
    {
        return "land_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  329 => 140,  326 => 139,  324 => 128,  318 => 127,  298 => 113,  294 => 112,  288 => 108,  282 => 107,  271 => 101,  262 => 102,  260 => 101,  255 => 99,  251 => 97,  245 => 96,  238 => 71,  231 => 67,  227 => 66,  224 => 65,  221 => 64,  214 => 55,  210 => 54,  207 => 53,  201 => 52,  187 => 87,  172 => 85,  168 => 84,  162 => 80,  155 => 76,  151 => 75,  148 => 74,  146 => 73,  143 => 72,  141 => 52,  122 => 36,  116 => 32,  110 => 31,  101 => 25,  98 => 24,  96 => 13,  90 => 12,  78 => 10,  69 => 142,  67 => 127,  64 => 126,  62 => 107,  58 => 105,  56 => 96,  53 => 95,  51 => 31,  43 => 27,  41 => 12,  36 => 10,  30 => 6,);
    }
}
/* {#*/
/*    This is the base template used as the application layout which contains the*/
/*    common elements and decorates all the other templates.*/
/*    See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts*/
/* #}*/
/* <!DOCTYPE html>*/
/* <html>*/
/* <head>*/
/*     <meta charset="UTF-8" />*/
/*     <title>{% block title %}Secret blog{% endblock %}</title>*/
/* */
/*     {% block stylesheets %}*/
/*         {# uncomment the following lines to compile SCSS assets with Assetic*/
/* */
/*             {% stylesheets filter="scssphp" output="css/app.css"*/
/*                 "%kernel.root_dir%/Resources/assets/scss/bootstrap.scss"*/
/*                 "%kernel.root_dir%/Resources/assets/scss/font-awesome.scss"*/
/*                 "%kernel.root_dir%/Resources/assets/css/*.css"*/
/*                 "%kernel.root_dir%/Resources/assets/scss/main.scss"*/
/*             %}*/
/*                 <link rel="stylesheet" href="{{ asset_url }}" />*/
/*             {% endstylesheets %}*/
/*         #}*/
/* */
/*         <link rel="stylesheet" href="{{ asset('css/app.css') }}">*/
/*     {% endblock %}*/
/*     <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/* </head>*/
/* */
/* <body>*/
/* {% block header %}*/
/*     <header>*/
/*         <div class="navbar navbar-default navbar-static-top" role="navigation">*/
/*             <div class="container">*/
/*                 <div class="navbar-header">*/
/*                     <a class="navbar-brand" href="{{ path('homepage') }}">*/
/*                         Landing*/
/*                     </a>*/
/* */
/*                     <button type="button" class="navbar-toggle"*/
/*                             data-toggle="collapse"*/
/*                             data-target=".navbar-collapse">*/
/*                         <span class="sr-only">Toggle navigation</span>*/
/*                         <span class="icon-bar"></span>*/
/*                         <span class="icon-bar"></span>*/
/*                         <span class="icon-bar"></span>*/
/*                     </button>*/
/*                 </div>*/
/*                 <div class="navbar-collapse collapse">*/
/*                     <ul class="nav navbar-nav navbar-right">*/
/* */
/*                         {% block header_navigation_links %}*/
/*                             <li>*/
/*                                 <a href="{{ path('blog_index') }}">*/
/*                                     <i class="fa fa-home"></i> {{ 'menu.homepage'|trans }}*/
/*                                 </a>*/
/*                             </li>*/
/* */
/*                             {# The 'app.user' condition is required to avoid issues in 404 and 500 error pages*/
/*                                As routing is done before security, error pages are not covered by any firewall.*/
/*                                This means you can't use is_granted() directly on these pages.*/
/*                                See http://symfony.com/doc/current/cookbook/security/form_login_setup.html#avoid-common-pitfalls*/
/*                             #}*/
/*                             {% if app.user and is_granted('ROLE_ADMIN') %}*/
/*                                 <li>*/
/*                                     <a href="{{ path('admin_post_index') }}">*/
/*                                         <i class="fa fa-lock"></i> {{ 'menu.admin'|trans }}*/
/*                                     </a>*/
/*                                 </li>*/
/*                             {% endif %}*/
/*                         {% endblock %}*/
/* */
/*                         {% if app.user %}*/
/*                             <li>*/
/*                                 <a href="{{ path('security_logout') }}">*/
/*                                     <i class="fa fa-sign-out"></i> {{ 'menu.logout'|trans }}*/
/*                                 </a>*/
/*                             </li>*/
/*                         {% endif %}*/
/* */
/*                         <li class="dropdown">*/
/*                             <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-globe"></i> <span class="caret"></span></a>*/
/*                             <ul class="dropdown-menu locales" role="menu">*/
/*                                 {% for locale in locales() %}*/
/*                                     <li {% if app.request.locale == locale.code %}class="active"{% endif %}><a href="{{ path(app.request.get('_route', 'blog_index'), app.request.get('_route_params', [])|merge({ _locale: locale.code })) }}">{{ locale.name|capitalize }}</a></li>*/
/*                                 {% endfor %}*/
/*                             </ul>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </header>*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     <div class="row">*/
/*         <div id="main" class="col-sm-9">*/
/*             {{ include('default/_flash_messages.html.twig') }}*/
/* */
/*             {% block main %}{% endblock %}*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* */
/* {% block footer %}*/
/*     <footer>*/
/*         <div class="container">*/
/*             <div class="row">*/
/*                 <div id="footer-copyright" class="col-md-6">*/
/*                     <p>&copy; {{ 'now'|date('Y') }}</p>*/
/*                     <p>{{ 'mit_license'|trans }}</p>*/
/*                 </div>*/
/*                 <div id="footer-resources" class="col-md-6">*/
/*                     <p>*/
/*                         <a href="#"><i class="fa fa-twitter"></i></a>*/
/*                         <a href="#"><i class="fa fa-facebook"></i></a>*/
/*                         <a href="#"><i class="fa fa-rss"></i></a>*/
/*                     </p>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </footer>*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {# uncomment the following lines to combine and minimize JavaScript assets with Assetic*/
/*         {% javascripts filter="?jsqueeze" output="js/app.js"*/
/*             "%kernel.root_dir%/Resources/assets/js/jquery-2.1.4.js"*/
/*             "%kernel.root_dir%/Resources/assets/js/moment.min.js"*/
/*             "%kernel.root_dir%/Resources/assets/js/bootstrap-3.3.4.js"*/
/*             "%kernel.root_dir%/Resources/assets/js/highlight.pack.js"*/
/*             "%kernel.root_dir%/Resources/assets/js/bootstrap-datetimepicker.min.js"*/
/*             "%kernel.root_dir%/Resources/assets/js/main.js" %}*/
/*             <script src="{{ asset_url }}"></script>*/
/*         {% endjavascripts %}*/
/*     #}*/
/* */
/*     <script src="{{ asset('js/app.js') }}"></script>*/
/* {% endblock %}*/
/* </body>*/
/* </html>*/
/* */
