<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_61e74217ad2b1bcb9835351711d55a3d8fada382185331c771dcdee0e9a7556b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e05a1412260e001277006f2a440ddee972a832149349ec893548b2ed7af2e809 = $this->env->getExtension("native_profiler");
        $__internal_e05a1412260e001277006f2a440ddee972a832149349ec893548b2ed7af2e809->enter($__internal_e05a1412260e001277006f2a440ddee972a832149349ec893548b2ed7af2e809_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_e05a1412260e001277006f2a440ddee972a832149349ec893548b2ed7af2e809->leave($__internal_e05a1412260e001277006f2a440ddee972a832149349ec893548b2ed7af2e809_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
