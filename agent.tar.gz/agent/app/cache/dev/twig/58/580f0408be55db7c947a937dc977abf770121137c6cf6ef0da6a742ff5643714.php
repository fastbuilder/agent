<?php

/* base.html.twig */
class __TwigTemplate_25423bf53acfd58d6f72b8c6d03325f2bf48fcbe968e2ec4352b039f2549d4a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ab1ad83b54a8accf8c30f08f2b196e76892cd6ed9508e572593cb63644145a1 = $this->env->getExtension("native_profiler");
        $__internal_0ab1ad83b54a8accf8c30f08f2b196e76892cd6ed9508e572593cb63644145a1->enter($__internal_0ab1ad83b54a8accf8c30f08f2b196e76892cd6ed9508e572593cb63644145a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 10
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 27
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>

    <body id=\"";
        // line 30
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

        ";
        // line 32
        $this->displayBlock('header', $context, $blocks);
        // line 91
        echo "
        <div class=\"container body-container\">
            ";
        // line 93
        $this->displayBlock('body', $context, $blocks);
        // line 117
        echo "        </div>

        ";
        // line 119
        $this->displayBlock('footer', $context, $blocks);
        // line 138
        echo "
        ";
        // line 139
        $this->displayBlock('javascripts', $context, $blocks);
        // line 154
        echo "    </body>
</html>
";
        
        $__internal_0ab1ad83b54a8accf8c30f08f2b196e76892cd6ed9508e572593cb63644145a1->leave($__internal_0ab1ad83b54a8accf8c30f08f2b196e76892cd6ed9508e572593cb63644145a1_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_cadd7ef4f275aca764cffbf6bb6095eac352b246f0914ea0a8c0fab6aa6017f8 = $this->env->getExtension("native_profiler");
        $__internal_cadd7ef4f275aca764cffbf6bb6095eac352b246f0914ea0a8c0fab6aa6017f8->enter($__internal_cadd7ef4f275aca764cffbf6bb6095eac352b246f0914ea0a8c0fab6aa6017f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Symfony Demo application";
        
        $__internal_cadd7ef4f275aca764cffbf6bb6095eac352b246f0914ea0a8c0fab6aa6017f8->leave($__internal_cadd7ef4f275aca764cffbf6bb6095eac352b246f0914ea0a8c0fab6aa6017f8_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_fdacb9c55313c092bfa3d9debe0e1d0d2d67d5c44b4d37f7a957c578c531c8f2 = $this->env->getExtension("native_profiler");
        $__internal_fdacb9c55313c092bfa3d9debe0e1d0d2d67d5c44b4d37f7a957c578c531c8f2->enter($__internal_fdacb9c55313c092bfa3d9debe0e1d0d2d67d5c44b4d37f7a957c578c531c8f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        ";
        // line 24
        echo "
            <link rel=\"stylesheet\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/app.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_fdacb9c55313c092bfa3d9debe0e1d0d2d67d5c44b4d37f7a957c578c531c8f2->leave($__internal_fdacb9c55313c092bfa3d9debe0e1d0d2d67d5c44b4d37f7a957c578c531c8f2_prof);

    }

    // line 30
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_1cbf3c087cb54b531057cf5720cc5bf12cb6e150e106e8d984ecb9e939728667 = $this->env->getExtension("native_profiler");
        $__internal_1cbf3c087cb54b531057cf5720cc5bf12cb6e150e106e8d984ecb9e939728667->enter($__internal_1cbf3c087cb54b531057cf5720cc5bf12cb6e150e106e8d984ecb9e939728667_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_1cbf3c087cb54b531057cf5720cc5bf12cb6e150e106e8d984ecb9e939728667->leave($__internal_1cbf3c087cb54b531057cf5720cc5bf12cb6e150e106e8d984ecb9e939728667_prof);

    }

    // line 32
    public function block_header($context, array $blocks = array())
    {
        $__internal_ac86d4f71ce5174ab190cfa1731b3353ad07a0d0eb8add87dc5a8c28eccc4b6a = $this->env->getExtension("native_profiler");
        $__internal_ac86d4f71ce5174ab190cfa1731b3353ad07a0d0eb8add87dc5a8c28eccc4b6a->enter($__internal_ac86d4f71ce5174ab190cfa1731b3353ad07a0d0eb8add87dc5a8c28eccc4b6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 33
        echo "            <header>
                <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
                    <div class=\"container\">
                        <div class=\"navbar-header\">
                            <a class=\"navbar-brand\" href=\"";
        // line 37
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\">Landing</a>
                            <a class=\"navbar-brand\" href=\"/ru/login\">Auth</a>
                            <button type=\"button\" class=\"navbar-toggle\"
                                    data-toggle=\"collapse\"
                                    data-target=\".navbar-collapse\">
                                <span class=\"sr-only\">Toggle navigation</span>
                            </button>
                        </div>
                        <div class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav navbar-right\">

                                ";
        // line 48
        $this->displayBlock('header_navigation_links', $context, $blocks);
        // line 68
        echo "
                                ";
        // line 69
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 70
            echo "                                    <li>
                                        <a href=\"";
            // line 71
            echo $this->env->getExtension('routing')->getPath("security_logout");
            echo "\">
                                            <i class=\"fa fa-sign-out\"></i> ";
            // line 72
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.logout"), "html", null, true);
            echo "
                                        </a>
                                    </li>
                                ";
        }
        // line 76
        echo "
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\"><i class=\"fa fa-globe\"></i> <span class=\"caret\"></span></a>
                                    <ul class=\"dropdown-menu locales\" role=\"menu\">
                                        ";
        // line 80
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('app.extension')->getLocales());
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 81
            echo "                                            <li ";
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                echo "class=\"active\"";
            }
            echo "><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route", 1 => "blog_index"), "method"), twig_array_merge($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params", 1 => array()), "method"), array("_locale" => $this->getAttribute($context["locale"], "code", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["locale"], "name", array())), "html", null, true);
            echo "</a></li>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 83
        echo "                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
        ";
        
        $__internal_ac86d4f71ce5174ab190cfa1731b3353ad07a0d0eb8add87dc5a8c28eccc4b6a->leave($__internal_ac86d4f71ce5174ab190cfa1731b3353ad07a0d0eb8add87dc5a8c28eccc4b6a_prof);

    }

    // line 48
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_ed09017cc531fb4976d78051fcdb691e00261630f63360feb5e61d9d9559daee = $this->env->getExtension("native_profiler");
        $__internal_ed09017cc531fb4976d78051fcdb691e00261630f63360feb5e61d9d9559daee->enter($__internal_ed09017cc531fb4976d78051fcdb691e00261630f63360feb5e61d9d9559daee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 49
        echo "                                    <li>
                                        <a href=\"";
        // line 50
        echo $this->env->getExtension('routing')->getPath("blog_index");
        echo "\">
                                            <i class=\"fa fa-home\"></i> ";
        // line 51
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.homepage"), "html", null, true);
        echo "
                                        </a>
                                    </li>

                                    ";
        // line 60
        echo "                                    ";
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) && $this->env->getExtension('security')->isGranted("ROLE_ADMIN"))) {
            // line 61
            echo "                                        <li>
                                            <a href=\"";
            // line 62
            echo $this->env->getExtension('routing')->getPath("admin_post_index");
            echo "\">
                                                <i class=\"fa fa-lock\"></i> ";
            // line 63
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.admin"), "html", null, true);
            echo "
                                            </a>
                                        </li>
                                    ";
        }
        // line 67
        echo "                                ";
        
        $__internal_ed09017cc531fb4976d78051fcdb691e00261630f63360feb5e61d9d9559daee->leave($__internal_ed09017cc531fb4976d78051fcdb691e00261630f63360feb5e61d9d9559daee_prof);

    }

    // line 93
    public function block_body($context, array $blocks = array())
    {
        $__internal_4c5cc7cc0a93cbec53a3584cc736587344ed58380fceb72e951fb913e947a0db = $this->env->getExtension("native_profiler");
        $__internal_4c5cc7cc0a93cbec53a3584cc736587344ed58380fceb72e951fb913e947a0db->enter($__internal_4c5cc7cc0a93cbec53a3584cc736587344ed58380fceb72e951fb913e947a0db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 94
        echo "                <div class=\"row\">
                    <div id=\"main\" class=\"col-sm-9\">
                        ";
        // line 96
        echo twig_include($this->env, $context, "default/_flash_messages.html.twig");
        echo "

                        ";
        // line 98
        $this->displayBlock('main', $context, $blocks);
        // line 99
        echo "                    </div>

                    <div id=\"sidebar\" class=\"col-sm-3\">
                        ";
        // line 102
        $this->displayBlock('sidebar', $context, $blocks);
        // line 114
        echo "                    </div>
                </div>
            ";
        
        $__internal_4c5cc7cc0a93cbec53a3584cc736587344ed58380fceb72e951fb913e947a0db->leave($__internal_4c5cc7cc0a93cbec53a3584cc736587344ed58380fceb72e951fb913e947a0db_prof);

    }

    // line 98
    public function block_main($context, array $blocks = array())
    {
        $__internal_51f2b3b01c1093f7177db5cb1c498e3912a9b1cc6ab7490509741f700b73caa3 = $this->env->getExtension("native_profiler");
        $__internal_51f2b3b01c1093f7177db5cb1c498e3912a9b1cc6ab7490509741f700b73caa3->enter($__internal_51f2b3b01c1093f7177db5cb1c498e3912a9b1cc6ab7490509741f700b73caa3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_51f2b3b01c1093f7177db5cb1c498e3912a9b1cc6ab7490509741f700b73caa3->leave($__internal_51f2b3b01c1093f7177db5cb1c498e3912a9b1cc6ab7490509741f700b73caa3_prof);

    }

    // line 102
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_933c80a23b3ece0bab6323192e14c5e5306280b13906cc595c131d4450e4b50c = $this->env->getExtension("native_profiler");
        $__internal_933c80a23b3ece0bab6323192e14c5e5306280b13906cc595c131d4450e4b50c->enter($__internal_933c80a23b3ece0bab6323192e14c5e5306280b13906cc595c131d4450e4b50c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 103
        echo "                            ";
        // line 104
        echo "                                ";
        // line 105
        echo "                                    ";
        // line 106
        echo "                                        ";
        // line 107
        echo "                                    ";
        // line 108
        echo "                                    ";
        // line 109
        echo "                                        ";
        // line 110
        echo "                                    ";
        // line 111
        echo "                                ";
        // line 112
        echo "                            ";
        // line 113
        echo "                        ";
        
        $__internal_933c80a23b3ece0bab6323192e14c5e5306280b13906cc595c131d4450e4b50c->leave($__internal_933c80a23b3ece0bab6323192e14c5e5306280b13906cc595c131d4450e4b50c_prof);

    }

    // line 119
    public function block_footer($context, array $blocks = array())
    {
        $__internal_8880d83740398a2015e23b46d4acccb65bc84b0c0b7dc9b48c6ec7a0939734ec = $this->env->getExtension("native_profiler");
        $__internal_8880d83740398a2015e23b46d4acccb65bc84b0c0b7dc9b48c6ec7a0939734ec->enter($__internal_8880d83740398a2015e23b46d4acccb65bc84b0c0b7dc9b48c6ec7a0939734ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 120
        echo "            <footer>
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"footer-copyright\" class=\"col-md-6\">
                            <p>&copy; ";
        // line 124
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo "</p>
                            <p>";
        // line 125
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("mit_license"), "html", null, true);
        echo "</p>
                        </div>
                        <div id=\"footer-resources\" class=\"col-md-6\">
                            <p>
                                <a href=\"#\"><i class=\"fa fa-twitter\"></i></a>
                                <a href=\"#\"><i class=\"fa fa-facebook\"></i></a>
                                <a href=\"#\"><i class=\"fa fa-rss\"></i></a>
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
        ";
        
        $__internal_8880d83740398a2015e23b46d4acccb65bc84b0c0b7dc9b48c6ec7a0939734ec->leave($__internal_8880d83740398a2015e23b46d4acccb65bc84b0c0b7dc9b48c6ec7a0939734ec_prof);

    }

    // line 139
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_d8c5d00e154e858b57a4eebde29e41d0e020d2cedd5897032896ef8b349af3f7 = $this->env->getExtension("native_profiler");
        $__internal_d8c5d00e154e858b57a4eebde29e41d0e020d2cedd5897032896ef8b349af3f7->enter($__internal_d8c5d00e154e858b57a4eebde29e41d0e020d2cedd5897032896ef8b349af3f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 140
        echo "        ";
        // line 151
        echo "
            <script src=\"";
        // line 152
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/app.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_d8c5d00e154e858b57a4eebde29e41d0e020d2cedd5897032896ef8b349af3f7->leave($__internal_d8c5d00e154e858b57a4eebde29e41d0e020d2cedd5897032896ef8b349af3f7_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  382 => 152,  379 => 151,  377 => 140,  371 => 139,  351 => 125,  347 => 124,  341 => 120,  335 => 119,  328 => 113,  326 => 112,  324 => 111,  322 => 110,  320 => 109,  318 => 108,  316 => 107,  314 => 106,  312 => 105,  310 => 104,  308 => 103,  302 => 102,  291 => 98,  282 => 114,  280 => 102,  275 => 99,  273 => 98,  268 => 96,  264 => 94,  258 => 93,  251 => 67,  244 => 63,  240 => 62,  237 => 61,  234 => 60,  227 => 51,  223 => 50,  220 => 49,  214 => 48,  200 => 83,  185 => 81,  181 => 80,  175 => 76,  168 => 72,  164 => 71,  161 => 70,  159 => 69,  156 => 68,  154 => 48,  140 => 37,  134 => 33,  128 => 32,  117 => 30,  108 => 25,  105 => 24,  103 => 13,  97 => 12,  85 => 10,  76 => 154,  74 => 139,  71 => 138,  69 => 119,  65 => 117,  63 => 93,  59 => 91,  57 => 32,  52 => 30,  45 => 27,  43 => 12,  38 => 10,  32 => 6,);
    }
}
/* {#*/
/*    This is the base template used as the application layout which contains the*/
/*    common elements and decorates all the other templates.*/
/*    See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts*/
/* #}*/
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Symfony Demo application{% endblock %}</title>*/
/* */
/*         {% block stylesheets %}*/
/*         {# uncomment the following lines to compile SCSS assets with Assetic*/
/* */
/*             {% stylesheets filter="scssphp" output="css/app.css"*/
/*                 "%kernel.root_dir%/Resources/assets/scss/bootstrap.scss"*/
/*                 "%kernel.root_dir%/Resources/assets/scss/font-awesome.scss"*/
/*                 "%kernel.root_dir%/Resources/assets/css/*.css"*/
/*                 "%kernel.root_dir%/Resources/assets/scss/main.scss"*/
/*             %}*/
/*                 <link rel="stylesheet" href="{{ asset_url }}" />*/
/*             {% endstylesheets %}*/
/*         #}*/
/* */
/*             <link rel="stylesheet" href="{{ asset('css/app.css') }}">*/
/*         {% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/* */
/*     <body id="{% block body_id %}{% endblock %}">*/
/* */
/*         {% block header %}*/
/*             <header>*/
/*                 <div class="navbar navbar-default navbar-static-top" role="navigation">*/
/*                     <div class="container">*/
/*                         <div class="navbar-header">*/
/*                             <a class="navbar-brand" href="{{ path('homepage') }}">Landing</a>*/
/*                             <a class="navbar-brand" href="/ru/login">Auth</a>*/
/*                             <button type="button" class="navbar-toggle"*/
/*                                     data-toggle="collapse"*/
/*                                     data-target=".navbar-collapse">*/
/*                                 <span class="sr-only">Toggle navigation</span>*/
/*                             </button>*/
/*                         </div>*/
/*                         <div class="navbar-collapse collapse">*/
/*                             <ul class="nav navbar-nav navbar-right">*/
/* */
/*                                 {% block header_navigation_links %}*/
/*                                     <li>*/
/*                                         <a href="{{ path('blog_index') }}">*/
/*                                             <i class="fa fa-home"></i> {{ 'menu.homepage'|trans }}*/
/*                                         </a>*/
/*                                     </li>*/
/* */
/*                                     {# The 'app.user' condition is required to avoid issues in 404 and 500 error pages*/
/*                                        As routing is done before security, error pages are not covered by any firewall.*/
/*                                        This means you can't use is_granted() directly on these pages.*/
/*                                        See http://symfony.com/doc/current/cookbook/security/form_login_setup.html#avoid-common-pitfalls*/
/*                                     #}*/
/*                                     {% if app.user and is_granted('ROLE_ADMIN') %}*/
/*                                         <li>*/
/*                                             <a href="{{ path('admin_post_index') }}">*/
/*                                                 <i class="fa fa-lock"></i> {{ 'menu.admin'|trans }}*/
/*                                             </a>*/
/*                                         </li>*/
/*                                     {% endif %}*/
/*                                 {% endblock %}*/
/* */
/*                                 {% if app.user %}*/
/*                                     <li>*/
/*                                         <a href="{{ path('security_logout') }}">*/
/*                                             <i class="fa fa-sign-out"></i> {{ 'menu.logout'|trans }}*/
/*                                         </a>*/
/*                                     </li>*/
/*                                 {% endif %}*/
/* */
/*                                 <li class="dropdown">*/
/*                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-globe"></i> <span class="caret"></span></a>*/
/*                                     <ul class="dropdown-menu locales" role="menu">*/
/*                                         {% for locale in locales() %}*/
/*                                             <li {% if app.request.locale == locale.code %}class="active"{% endif %}><a href="{{ path(app.request.get('_route', 'blog_index'), app.request.get('_route_params', [])|merge({ _locale: locale.code })) }}">{{ locale.name|capitalize }}</a></li>*/
/*                                         {% endfor %}*/
/*                                     </ul>*/
/*                                 </li>*/
/*                             </ul>*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </header>*/
/*         {% endblock %}*/
/* */
/*         <div class="container body-container">*/
/*             {% block body %}*/
/*                 <div class="row">*/
/*                     <div id="main" class="col-sm-9">*/
/*                         {{ include('default/_flash_messages.html.twig') }}*/
/* */
/*                         {% block main %}{% endblock %}*/
/*                     </div>*/
/* */
/*                     <div id="sidebar" class="col-sm-3">*/
/*                         {% block sidebar %}*/
/*                             {#<div class="section about">#}*/
/*                                 {#<div class="well well-lg">#}*/
/*                                     {#<p>#}*/
/*                                         {#{{ 'help.app_description'|trans|raw }}#}*/
/*                                     {#</p>#}*/
/*                                     {#<p>#}*/
/*                                         {#{{ 'help.more_information'|trans|raw }}#}*/
/*                                     {#</p>#}*/
/*                                 {#</div>#}*/
/*                             {#</div>#}*/
/*                         {% endblock %}*/
/*                     </div>*/
/*                 </div>*/
/*             {% endblock %}*/
/*         </div>*/
/* */
/*         {% block footer %}*/
/*             <footer>*/
/*                 <div class="container">*/
/*                     <div class="row">*/
/*                         <div id="footer-copyright" class="col-md-6">*/
/*                             <p>&copy; {{ 'now'|date('Y') }}</p>*/
/*                             <p>{{ 'mit_license'|trans }}</p>*/
/*                         </div>*/
/*                         <div id="footer-resources" class="col-md-6">*/
/*                             <p>*/
/*                                 <a href="#"><i class="fa fa-twitter"></i></a>*/
/*                                 <a href="#"><i class="fa fa-facebook"></i></a>*/
/*                                 <a href="#"><i class="fa fa-rss"></i></a>*/
/*                             </p>*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </footer>*/
/*         {% endblock %}*/
/* */
/*         {% block javascripts %}*/
/*         {# uncomment the following lines to combine and minimize JavaScript assets with Assetic*/
/*             {% javascripts filter="?jsqueeze" output="js/app.js"*/
/*                 "%kernel.root_dir%/Resources/assets/js/jquery-2.1.4.js"*/
/*                 "%kernel.root_dir%/Resources/assets/js/moment.min.js"*/
/*                 "%kernel.root_dir%/Resources/assets/js/bootstrap-3.3.4.js"*/
/*                 "%kernel.root_dir%/Resources/assets/js/highlight.pack.js"*/
/*                 "%kernel.root_dir%/Resources/assets/js/bootstrap-datetimepicker.min.js"*/
/*                 "%kernel.root_dir%/Resources/assets/js/main.js" %}*/
/*                 <script src="{{ asset_url }}"></script>*/
/*             {% endjavascripts %}*/
/*         #}*/
/* */
/*             <script src="{{ asset('js/app.js') }}"></script>*/
/*         {% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
