<?php

/* default/homepage.html.twig */
class __TwigTemplate_52b6c76bc872bdac87e8edb88affaaf9a65536a9187cd5ab2e859dbb6c3f634f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("land_base.html.twig", "default/homepage.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "land_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e77fa1752fc9918ca7c793981f9968aa0f315e3db5951cf263387f80bd22cfd = $this->env->getExtension("native_profiler");
        $__internal_2e77fa1752fc9918ca7c793981f9968aa0f315e3db5951cf263387f80bd22cfd->enter($__internal_2e77fa1752fc9918ca7c793981f9968aa0f315e3db5951cf263387f80bd22cfd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2e77fa1752fc9918ca7c793981f9968aa0f315e3db5951cf263387f80bd22cfd->leave($__internal_2e77fa1752fc9918ca7c793981f9968aa0f315e3db5951cf263387f80bd22cfd_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_8de2fd476c44512af8b57af7faa09be2488463fc28fefec6e1a07ed7d99d2732 = $this->env->getExtension("native_profiler");
        $__internal_8de2fd476c44512af8b57af7faa09be2488463fc28fefec6e1a07ed7d99d2732->enter($__internal_8de2fd476c44512af8b57af7faa09be2488463fc28fefec6e1a07ed7d99d2732_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "homepage";
        
        $__internal_8de2fd476c44512af8b57af7faa09be2488463fc28fefec6e1a07ed7d99d2732->leave($__internal_8de2fd476c44512af8b57af7faa09be2488463fc28fefec6e1a07ed7d99d2732_prof);

    }

    // line 9
    public function block_header($context, array $blocks = array())
    {
        $__internal_4c34eda23d1867dcf6ada43bddaeb209097664f861149803d94ce31861316497 = $this->env->getExtension("native_profiler");
        $__internal_4c34eda23d1867dcf6ada43bddaeb209097664f861149803d94ce31861316497->enter($__internal_4c34eda23d1867dcf6ada43bddaeb209097664f861149803d94ce31861316497_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        
        $__internal_4c34eda23d1867dcf6ada43bddaeb209097664f861149803d94ce31861316497->leave($__internal_4c34eda23d1867dcf6ada43bddaeb209097664f861149803d94ce31861316497_prof);

    }

    // line 10
    public function block_footer($context, array $blocks = array())
    {
        $__internal_1afe17cd45d0479fb7626112a3d66fd0209184f5a4ca26f9ccfe4dcc7ecc023e = $this->env->getExtension("native_profiler");
        $__internal_1afe17cd45d0479fb7626112a3d66fd0209184f5a4ca26f9ccfe4dcc7ecc023e->enter($__internal_1afe17cd45d0479fb7626112a3d66fd0209184f5a4ca26f9ccfe4dcc7ecc023e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_1afe17cd45d0479fb7626112a3d66fd0209184f5a4ca26f9ccfe4dcc7ecc023e->leave($__internal_1afe17cd45d0479fb7626112a3d66fd0209184f5a4ca26f9ccfe4dcc7ecc023e_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_6a72653f757959e20b690065b51d2a758834d47c5b6c39988a294ec7772ce113 = $this->env->getExtension("native_profiler");
        $__internal_6a72653f757959e20b690065b51d2a758834d47c5b6c39988a294ec7772ce113->enter($__internal_6a72653f757959e20b690065b51d2a758834d47c5b6c39988a294ec7772ce113_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_6a72653f757959e20b690065b51d2a758834d47c5b6c39988a294ec7772ce113->leave($__internal_6a72653f757959e20b690065b51d2a758834d47c5b6c39988a294ec7772ce113_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3fc2e0bba933c27a304f23713a86cd390466c4246a034a6d2521d9e5dbaef611 = $this->env->getExtension("native_profiler");
        $__internal_3fc2e0bba933c27a304f23713a86cd390466c4246a034a6d2521d9e5dbaef611->enter($__internal_3fc2e0bba933c27a304f23713a86cd390466c4246a034a6d2521d9e5dbaef611_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "    <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css\" />
    <link href=\"//cdnjs.cloudflare.com/ajax/libs/animate.css/3.1.1/animate.min.css\" rel=\"stylesheet\" />
    <link rel=\"stylesheet\" href=\"//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css\" />
    <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_3fc2e0bba933c27a304f23713a86cd390466c4246a034a6d2521d9e5dbaef611->leave($__internal_3fc2e0bba933c27a304f23713a86cd390466c4246a034a6d2521d9e5dbaef611_prof);

    }

    // line 18
    public function block_body($context, array $blocks = array())
    {
        $__internal_e6e7f75ce6bb28d8a12ba61790e3dd242f51939e3f43ce745c2e96751509a50d = $this->env->getExtension("native_profiler");
        $__internal_e6e7f75ce6bb28d8a12ba61790e3dd242f51939e3f43ce745c2e96751509a50d->enter($__internal_e6e7f75ce6bb28d8a12ba61790e3dd242f51939e3f43ce745c2e96751509a50d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 19
        echo "    <nav id=\"topNav\" class=\"navbar navbar-default navbar-fixed-top\">
        <div class=\"container-fluid\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-navbar\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand page-scroll\" href=\"#first\"><i class=\"ion-ios-analytics-outline\"></i>Secret Agency</a>
            </div>
            <div class=\"navbar-collapse collapse\" id=\"bs-navbar\">
                <ul class=\"nav navbar-nav\">
                    <li>
                        <a class=\"page-scroll\" href=\"#one\">Intro</a>
                    </li>
                    <li>
                        <a class=\"page-scroll\" href=\"#three\">Gallery</a>
                    </li>
                    <li>
                        <a class=\"page-scroll\" href=\"#four\">Features</a>
                    </li>
                    <li>
                        <a class=\"page-scroll\" href=\"#last\">Contact</a>
                    </li>
                    <li>
                        <a class=\"page-scroll\" href=\"/ru/blog\">Blog</a>
                    </li>
                </ul>
                <ul class=\"nav navbar-nav navbar-right\">
                    <li>
                        <a class=\"page-scroll\" data-toggle=\"modal\" title=\"A free Bootstrap video landing theme\" href=\"/ru/login\">Auth</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <header id=\"first\">
        <div class=\"header-content\">
            <div class=\"inner\">
                <h1 class=\"cursive\">Secret agency portsl</h1>
                <h4>There is no knowledgem, that is not power.</h4>
                <hr>
                <a href=\"#video-background\" id=\"toggleVideo\" data-toggle=\"collapse\" class=\"btn btn-primary btn-xl\">Toggle Video</a> &nbsp;
            </div>
        </div>
        <video autoplay=\"\" loop=\"\" class=\"fillWidth fadeIn wow collapse in\" data-wow-delay=\"0.5s\" poster=\"https://s3-us-west-2.amazonaws.com/coverr/poster/Traffic-blurred2.jpg\" id=\"video-background\">
            <source src=\"https://s3-us-west-2.amazonaws.com/coverr/mp4/Traffic-blurred2.mp4\" type=\"video/mp4\">Your browser does not support the video tag. I suggest you upgrade your browser.
        </video>
    </header>
    <section class=\"bg-primary\" id=\"one\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 text-center\">
                    <h2 class=\"margin-top-0 text-primary\">Our mission</h2>
                    <br>
                    <p class=\"text-faded\">
                        Our mission is to help protect you, your children, your communities, and your businesses from the most dangerous threats facing our nation—from international and domestic terrorists to spies on U.S. soil…from cyber villains to corrupt government officials…from mobsters to violent street gangs…from child predators to serial killers.
                        Along the way, we help defend and uphold our nation’s economy, physical and electronic infrastructure, and democracy. Learn more about how we have evolved into a more proactive, threat-driven security agency in recent years.
                    </p>
                    <a href=\"#three\" class=\"btn btn-default btn-xl page-scroll\">Learn More</a>
                </div>
            </div>
        </div>
    </section>
    </section>
    <section id=\"three\" class=\"no-padding\">
        <div class=\"container-fluid\">
            <div class=\"row no-gutter\">
                <div class=\"col-lg-4 col-sm-6\">
                    <a href=\"#galleryModal\" class=\"gallery-box\" data-toggle=\"modal\" data-src=\"//splashbase.s3.amazonaws.com/unsplash/regular/photo-1430916273432-273c2db881a0%3Fq%3D75%26fm%3Djpg%26w%3D1080%26fit%3Dmax%26s%3Df047e8284d2fdc1df0fd57a5d294614d\">
                        <img src=\"//splashbase.s3.amazonaws.com/unsplash/regular/photo-1430916273432-273c2db881a0%3Fq%3D75%26fm%3Djpg%26w%3D1080%26fit%3Dmax%26s%3Df047e8284d2fdc1df0fd57a5d294614d\" class=\"img-responsive\" alt=\"Image 1\">
                        <div class=\"gallery-box-caption\">
                            <div class=\"gallery-box-content\">
                                <div>
                                    <i class=\"icon-lg ion-ios-search\"></i>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class=\"col-lg-4 col-sm-6\">
                    <a href=\"#galleryModal\" class=\"gallery-box\" data-toggle=\"modal\" data-src=\"//splashbase.s3.amazonaws.com/getrefe/regular/tumblr_nqune4OGHl1slhhf0o1_1280.jpg\">
                        <img src=\"//splashbase.s3.amazonaws.com/getrefe/regular/tumblr_nqune4OGHl1slhhf0o1_1280.jpg\" class=\"img-responsive\" alt=\"Image 2\">
                        <div class=\"gallery-box-caption\">
                            <div class=\"gallery-box-content\">
                                <div>
                                    <i class=\"icon-lg ion-ios-search\"></i>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class=\"col-lg-4 col-sm-6\">
                    <a href=\"#galleryModal\" class=\"gallery-box\" data-toggle=\"modal\" data-src=\"//splashbase.s3.amazonaws.com/unsplash/regular/photo-1433959352364-9314c5b6eb0b%3Fq%3D75%26fm%3Djpg%26w%3D1080%26fit%3Dmax%26s%3D3b9bc6caa190332e91472b6828a120a4\">
                        <img src=\"//splashbase.s3.amazonaws.com/unsplash/regular/photo-1433959352364-9314c5b6eb0b%3Fq%3D75%26fm%3Djpg%26w%3D1080%26fit%3Dmax%26s%3D3b9bc6caa190332e91472b6828a120a4\" class=\"img-responsive\" alt=\"Image 3\">
                        <div class=\"gallery-box-caption\">
                            <div class=\"gallery-box-content\">
                                <div>
                                    <i class=\"icon-lg ion-ios-search\"></i>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class=\"col-lg-4 col-sm-6\">
                    <a href=\"#galleryModal\" class=\"gallery-box\" data-toggle=\"modal\" data-src=\"//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-moto-drawing-illusion-nabeel-1440x960.jpg\">
                        <img src=\"//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-moto-drawing-illusion-nabeel-1440x960.jpg\" class=\"img-responsive\" alt=\"Image 4\">
                        <div class=\"gallery-box-caption\">
                            <div class=\"gallery-box-content\">
                                <div>
                                    <i class=\"icon-lg ion-ios-search\"></i>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class=\"col-lg-4 col-sm-6\">
                    <a href=\"#galleryModal\" class=\"gallery-box\" data-toggle=\"modal\" data-src=\"//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-new-york-crosswalk-nabeel-1440x960.jpg\">
                        <img src=\"//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-new-york-crosswalk-nabeel-1440x960.jpg\" class=\"img-responsive\" alt=\"Image 5\">
                        <div class=\"gallery-box-caption\">
                            <div class=\"gallery-box-content\">
                                <div>
                                    <i class=\"icon-lg ion-ios-search\"></i>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class=\"col-lg-4 col-sm-6\">
                    <a href=\"#galleryModal\" class=\"gallery-box\" data-toggle=\"modal\" data-src=\"//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-clothes-exotic-travel-nabeel-1440x960.jpg\">
                        <img src=\"//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-clothes-exotic-travel-nabeel-1440x960.jpg\" class=\"img-responsive\" alt=\"Image 6\">
                        <div class=\"gallery-box-caption\">
                            <div class=\"gallery-box-content\">
                                <div>
                                    <i class=\"icon-lg ion-ios-search\"></i>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <section class=\"container-fluid\" id=\"four\">
        <div class=\"row\">
            <div class=\"col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4\">
                <h2 class=\"text-center text-primary\">Features</h2>
                <hr>
                <div class=\"media wow fadeInRight\">
                    <h3>Simple</h3>
                    <div class=\"media-body media-middle\">
                        <p>What could be easier? Get started fast with this landing page starter theme.</p>
                    </div>
                    <div class=\"media-right\">
                        <i class=\"icon-lg ion-ios-bolt-outline\"></i>
                    </div>
                </div>
                <hr>
                <div class=\"media wow fadeIn\">
                    <h3>Free</h3>
                    <div class=\"media-left\">
                        <a href=\"#alertModal\" data-toggle=\"modal\" data-target=\"#alertModal\"><i class=\"icon-lg ion-ios-cloud-download-outline\"></i></a>
                    </div>
                    <div class=\"media-body media-middle\">
                        <p>Yes, please. Grab it for yourself, and make something awesome with this.</p>
                    </div>
                </div>
                <hr>
                <div class=\"media wow fadeInRight\">
                    <h3>Unique</h3>
                    <div class=\"media-body media-middle\">
                        <p>Because you don't want your Bootstrap site, to look like a Bootstrap site.</p>
                    </div>
                    <div class=\"media-right\">
                        <i class=\"icon-lg ion-ios-snowy\"></i>
                    </div>
                </div>
                <hr>
                <div class=\"media wow fadeIn\">
                    <h3>Popular</h3>
                    <div class=\"media-left\">
                        <i class=\"icon-lg ion-ios-heart-outline\"></i>
                    </div>
                    <div class=\"media-body media-middle\">
                        <p>There's good reason why Bootstrap is the most used frontend framework in the world.</p>
                    </div>
                </div>
                <hr>
                <div class=\"media wow fadeInRight\">
                    <h3>Tested</h3>
                    <div class=\"media-body media-middle\">
                        <p>Bootstrap is matured and well-tested. It's a stable codebase that provides consistency.</p>
                    </div>
                    <div class=\"media-right\">
                        <i class=\"icon-lg ion-ios-flask-outline\"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </aside>
    <section id=\"last\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-8 col-lg-offset-2 text-center\">
                    <h2 class=\"margin-top-0 wow fadeIn\">Get in Touch</h2>
                    <hr class=\"primary\">
                    <p>We love feedback. Fill out the form below and we'll get back to you as soon as possible.</p>
                </div>
                <div class=\"col-lg-10 col-lg-offset-1 text-center\">
                    <form class=\"contact-form row\">
                        <div class=\"col-md-4\">
                            <label></label>
                            <input type=\"text\" class=\"form-control\" placeholder=\"Name\">
                        </div>
                        <div class=\"col-md-4\">
                            <label></label>
                            <input type=\"text\" class=\"form-control\" placeholder=\"Email\">
                        </div>
                        <div class=\"col-md-4\">
                            <label></label>
                            <input type=\"text\" class=\"form-control\" placeholder=\"Phone\">
                        </div>
                        <div class=\"col-md-12\">
                            <label></label>
                            <textarea class=\"form-control\" rows=\"9\" placeholder=\"Your message here..\"></textarea>
                        </div>
                        <div class=\"col-md-4 col-md-offset-4\">
                            <label></label>
                            <button type=\"button\" data-toggle=\"modal\" data-target=\"#alertModal\" class=\"btn btn-primary btn-block btn-lg\">Send <i class=\"ion-android-arrow-forward\"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <footer id=\"footer\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-xs-6 col-sm-3 column\">
                    <h4>Information</h4>
                    <ul class=\"list-unstyled\">
                        <li><a href=\"\">Products</a></li>
                        <li><a href=\"\">Services</a></li>
                        <li><a href=\"\">Benefits</a></li>
                        <li><a href=\"\">Developers</a></li>
                    </ul>
                </div>
                <div class=\"col-xs-6 col-sm-3 column\">
                    <h4>About</h4>
                    <ul class=\"list-unstyled\">
                        <li><a href=\"#\">Contact Us</a></li>
                        <li><a href=\"#\">Delivery Information</a></li>
                        <li><a href=\"#\">Privacy Policy</a></li>
                        <li><a href=\"#\">Terms &amp; Conditions</a></li>
                    </ul>
                </div>
                <div class=\"col-xs-12 col-sm-3 column\">
                    <h4>Stay Posted</h4>
                    <form>
                        <div class=\"form-group\">
                            <input type=\"text\" class=\"form-control\" title=\"No spam, we promise!\" placeholder=\"Tell us your email\">
                        </div>
                        <div class=\"form-group\">
                            <button class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#alertModal\" type=\"button\">Subscribe for updates</button>
                        </div>
                    </form>
                </div>
                <div class=\"col-xs-12 col-sm-3 text-right\">
                    <h4>Follow</h4>
                    <ul class=\"list-inline\">
                        <li><a rel=\"nofollow\" href=\"\" title=\"Twitter\"><i class=\"icon-lg ion-social-twitter-outline\"></i></a>&nbsp;</li>
                        <li><a rel=\"nofollow\" href=\"\" title=\"Facebook\"><i class=\"icon-lg ion-social-facebook-outline\"></i></a>&nbsp;</li>
                        <li><a rel=\"nofollow\" href=\"\" title=\"Dribble\"><i class=\"icon-lg ion-social-dribbble-outline\"></i></a></li>
                    </ul>
                </div>
            </div>
            <br/>
            <span class=\"pull-right text-muted small\"><a href=\"#\">liaros</a> ©2016 Company</span>
        </div>
    </footer>
    <div id=\"galleryModal\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
        <div class=\"modal-dialog modal-lg\">
            <div class=\"modal-content\">
                <div class=\"modal-body\">
                    <img src=\"//placehold.it/1200x700/222?text=...\" id=\"galleryImage\" class=\"img-responsive\" />
                    <p>
                        <br/>
                        <button class=\"btn btn-primary btn-lg center-block\" data-dismiss=\"modal\" aria-hidden=\"true\">Close <i class=\"ion-android-close\"></i></button>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div id=\"aboutModal\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
        <div class=\"modal-dialog\">
            <div class=\"modal-content\">
                <div class=\"modal-body\">
                    <h2 class=\"text-center\">Landing Zero Theme</h2>
                    <h5 class=\"text-center\">
                        A free, responsive landing page theme built by BootstrapZero.
                    </h5>
                    <p class=\"text-justify\">
                        This is a single-page Bootstrap template with a sleek dark/grey color scheme, accent color and smooth scrolling.
                        There are vertical content sections with subtle animations that are activated when scrolled into view using the jQuery WOW plugin. There is also a gallery with modals
                        that work nicely to showcase your work portfolio. Other features include a contact form, email subscribe form, multi-column footer. Uses Questrial Google Font and Ionicons.
                    </p>
                    <p class=\"text-center\"><a href=\"http://www.bootstrapzero.com\">Download at BootstrapZero</a></p>
                    <br/>
                    <button class=\"btn btn-primary btn-lg center-block\" data-dismiss=\"modal\" aria-hidden=\"true\"> OK </button>
                </div>
            </div>
        </div>
    </div>
    <div id=\"alertModal\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
        <div class=\"modal-dialog modal-sm\">
            <div class=\"modal-content\">
                <div class=\"modal-body\">
                    <h2 class=\"text-center\">Nice Job!</h2>
                    <p class=\"text-center\">You clicked the button, but it doesn't actually go anywhere because this is only a demo.</p>
                    <br/>
                    <button class=\"btn btn-primary btn-lg center-block\" data-dismiss=\"modal\" aria-hidden=\"true\">OK <i class=\"ion-android-close\"></i></button>
                </div>
            </div>
        </div>
    </div>
    <!--scripts loaded here from cdn for performance -->
    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js\"></script>
    <script src=\"//cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js\"></script>
    <script src=\"//cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js\"></script>
    <script src=\"";
        // line 351
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/scripts.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_e6e7f75ce6bb28d8a12ba61790e3dd242f51939e3f43ce745c2e96751509a50d->leave($__internal_e6e7f75ce6bb28d8a12ba61790e3dd242f51939e3f43ce745c2e96751509a50d_prof);

    }

    public function getTemplateName()
    {
        return "default/homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  444 => 351,  110 => 19,  104 => 18,  95 => 16,  90 => 13,  84 => 12,  73 => 11,  62 => 10,  51 => 9,  39 => 3,  11 => 1,);
    }
}
/* {% extends 'land_base.html.twig' %}*/
/* */
/* {% block body_id 'homepage' %}*/
/* */
/* {#*/
/*     the homepage is a special page which displays neither a header nor a footer.*/
/*     this is done with the 'trick' of defining empty Twig blocks without any content*/
/* #}*/
/* {% block header %}{% endblock %}*/
/* {% block footer %}{% endblock %}*/
/* {% block javascripts %}{% endblock %}*/
/* {% block stylesheets %}*/
/*     <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" />*/
/*     <link href="//cdnjs.cloudflare.com/ajax/libs/animate.css/3.1.1/animate.min.css" rel="stylesheet" />*/
/*     <link rel="stylesheet" href="//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" />*/
/*     <link rel="stylesheet" href="{{ asset('css/styles.css') }}" />*/
/* {% endblock %}*/
/* {% block body %}*/
/*     <nav id="topNav" class="navbar navbar-default navbar-fixed-top">*/
/*         <div class="container-fluid">*/
/*             <div class="navbar-header">*/
/*                 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-navbar">*/
/*                     <span class="sr-only">Toggle navigation</span>*/
/*                     <span class="icon-bar"></span>*/
/*                     <span class="icon-bar"></span>*/
/*                     <span class="icon-bar"></span>*/
/*                 </button>*/
/*                 <a class="navbar-brand page-scroll" href="#first"><i class="ion-ios-analytics-outline"></i>Secret Agency</a>*/
/*             </div>*/
/*             <div class="navbar-collapse collapse" id="bs-navbar">*/
/*                 <ul class="nav navbar-nav">*/
/*                     <li>*/
/*                         <a class="page-scroll" href="#one">Intro</a>*/
/*                     </li>*/
/*                     <li>*/
/*                         <a class="page-scroll" href="#three">Gallery</a>*/
/*                     </li>*/
/*                     <li>*/
/*                         <a class="page-scroll" href="#four">Features</a>*/
/*                     </li>*/
/*                     <li>*/
/*                         <a class="page-scroll" href="#last">Contact</a>*/
/*                     </li>*/
/*                     <li>*/
/*                         <a class="page-scroll" href="/ru/blog">Blog</a>*/
/*                     </li>*/
/*                 </ul>*/
/*                 <ul class="nav navbar-nav navbar-right">*/
/*                     <li>*/
/*                         <a class="page-scroll" data-toggle="modal" title="A free Bootstrap video landing theme" href="/ru/login">Auth</a>*/
/*                     </li>*/
/*                 </ul>*/
/*             </div>*/
/*         </div>*/
/*     </nav>*/
/*     <header id="first">*/
/*         <div class="header-content">*/
/*             <div class="inner">*/
/*                 <h1 class="cursive">Secret agency portsl</h1>*/
/*                 <h4>There is no knowledgem, that is not power.</h4>*/
/*                 <hr>*/
/*                 <a href="#video-background" id="toggleVideo" data-toggle="collapse" class="btn btn-primary btn-xl">Toggle Video</a> &nbsp;*/
/*             </div>*/
/*         </div>*/
/*         <video autoplay="" loop="" class="fillWidth fadeIn wow collapse in" data-wow-delay="0.5s" poster="https://s3-us-west-2.amazonaws.com/coverr/poster/Traffic-blurred2.jpg" id="video-background">*/
/*             <source src="https://s3-us-west-2.amazonaws.com/coverr/mp4/Traffic-blurred2.mp4" type="video/mp4">Your browser does not support the video tag. I suggest you upgrade your browser.*/
/*         </video>*/
/*     </header>*/
/*     <section class="bg-primary" id="one">*/
/*         <div class="container">*/
/*             <div class="row">*/
/*                 <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 text-center">*/
/*                     <h2 class="margin-top-0 text-primary">Our mission</h2>*/
/*                     <br>*/
/*                     <p class="text-faded">*/
/*                         Our mission is to help protect you, your children, your communities, and your businesses from the most dangerous threats facing our nation—from international and domestic terrorists to spies on U.S. soil…from cyber villains to corrupt government officials…from mobsters to violent street gangs…from child predators to serial killers.*/
/*                         Along the way, we help defend and uphold our nation’s economy, physical and electronic infrastructure, and democracy. Learn more about how we have evolved into a more proactive, threat-driven security agency in recent years.*/
/*                     </p>*/
/*                     <a href="#three" class="btn btn-default btn-xl page-scroll">Learn More</a>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/*     </section>*/
/*     <section id="three" class="no-padding">*/
/*         <div class="container-fluid">*/
/*             <div class="row no-gutter">*/
/*                 <div class="col-lg-4 col-sm-6">*/
/*                     <a href="#galleryModal" class="gallery-box" data-toggle="modal" data-src="//splashbase.s3.amazonaws.com/unsplash/regular/photo-1430916273432-273c2db881a0%3Fq%3D75%26fm%3Djpg%26w%3D1080%26fit%3Dmax%26s%3Df047e8284d2fdc1df0fd57a5d294614d">*/
/*                         <img src="//splashbase.s3.amazonaws.com/unsplash/regular/photo-1430916273432-273c2db881a0%3Fq%3D75%26fm%3Djpg%26w%3D1080%26fit%3Dmax%26s%3Df047e8284d2fdc1df0fd57a5d294614d" class="img-responsive" alt="Image 1">*/
/*                         <div class="gallery-box-caption">*/
/*                             <div class="gallery-box-content">*/
/*                                 <div>*/
/*                                     <i class="icon-lg ion-ios-search"></i>*/
/*                                 </div>*/
/*                             </div>*/
/*                         </div>*/
/*                     </a>*/
/*                 </div>*/
/*                 <div class="col-lg-4 col-sm-6">*/
/*                     <a href="#galleryModal" class="gallery-box" data-toggle="modal" data-src="//splashbase.s3.amazonaws.com/getrefe/regular/tumblr_nqune4OGHl1slhhf0o1_1280.jpg">*/
/*                         <img src="//splashbase.s3.amazonaws.com/getrefe/regular/tumblr_nqune4OGHl1slhhf0o1_1280.jpg" class="img-responsive" alt="Image 2">*/
/*                         <div class="gallery-box-caption">*/
/*                             <div class="gallery-box-content">*/
/*                                 <div>*/
/*                                     <i class="icon-lg ion-ios-search"></i>*/
/*                                 </div>*/
/*                             </div>*/
/*                         </div>*/
/*                     </a>*/
/*                 </div>*/
/*                 <div class="col-lg-4 col-sm-6">*/
/*                     <a href="#galleryModal" class="gallery-box" data-toggle="modal" data-src="//splashbase.s3.amazonaws.com/unsplash/regular/photo-1433959352364-9314c5b6eb0b%3Fq%3D75%26fm%3Djpg%26w%3D1080%26fit%3Dmax%26s%3D3b9bc6caa190332e91472b6828a120a4">*/
/*                         <img src="//splashbase.s3.amazonaws.com/unsplash/regular/photo-1433959352364-9314c5b6eb0b%3Fq%3D75%26fm%3Djpg%26w%3D1080%26fit%3Dmax%26s%3D3b9bc6caa190332e91472b6828a120a4" class="img-responsive" alt="Image 3">*/
/*                         <div class="gallery-box-caption">*/
/*                             <div class="gallery-box-content">*/
/*                                 <div>*/
/*                                     <i class="icon-lg ion-ios-search"></i>*/
/*                                 </div>*/
/*                             </div>*/
/*                         </div>*/
/*                     </a>*/
/*                 </div>*/
/*                 <div class="col-lg-4 col-sm-6">*/
/*                     <a href="#galleryModal" class="gallery-box" data-toggle="modal" data-src="//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-moto-drawing-illusion-nabeel-1440x960.jpg">*/
/*                         <img src="//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-moto-drawing-illusion-nabeel-1440x960.jpg" class="img-responsive" alt="Image 4">*/
/*                         <div class="gallery-box-caption">*/
/*                             <div class="gallery-box-content">*/
/*                                 <div>*/
/*                                     <i class="icon-lg ion-ios-search"></i>*/
/*                                 </div>*/
/*                             </div>*/
/*                         </div>*/
/*                     </a>*/
/*                 </div>*/
/*                 <div class="col-lg-4 col-sm-6">*/
/*                     <a href="#galleryModal" class="gallery-box" data-toggle="modal" data-src="//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-new-york-crosswalk-nabeel-1440x960.jpg">*/
/*                         <img src="//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-new-york-crosswalk-nabeel-1440x960.jpg" class="img-responsive" alt="Image 5">*/
/*                         <div class="gallery-box-caption">*/
/*                             <div class="gallery-box-content">*/
/*                                 <div>*/
/*                                     <i class="icon-lg ion-ios-search"></i>*/
/*                                 </div>*/
/*                             </div>*/
/*                         </div>*/
/*                     </a>*/
/*                 </div>*/
/*                 <div class="col-lg-4 col-sm-6">*/
/*                     <a href="#galleryModal" class="gallery-box" data-toggle="modal" data-src="//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-clothes-exotic-travel-nabeel-1440x960.jpg">*/
/*                         <img src="//splashbase.s3.amazonaws.com/lifeofpix/regular/Life-of-Pix-free-stock-photos-clothes-exotic-travel-nabeel-1440x960.jpg" class="img-responsive" alt="Image 6">*/
/*                         <div class="gallery-box-caption">*/
/*                             <div class="gallery-box-content">*/
/*                                 <div>*/
/*                                     <i class="icon-lg ion-ios-search"></i>*/
/*                                 </div>*/
/*                             </div>*/
/*                         </div>*/
/*                     </a>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/*     <section class="container-fluid" id="four">*/
/*         <div class="row">*/
/*             <div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">*/
/*                 <h2 class="text-center text-primary">Features</h2>*/
/*                 <hr>*/
/*                 <div class="media wow fadeInRight">*/
/*                     <h3>Simple</h3>*/
/*                     <div class="media-body media-middle">*/
/*                         <p>What could be easier? Get started fast with this landing page starter theme.</p>*/
/*                     </div>*/
/*                     <div class="media-right">*/
/*                         <i class="icon-lg ion-ios-bolt-outline"></i>*/
/*                     </div>*/
/*                 </div>*/
/*                 <hr>*/
/*                 <div class="media wow fadeIn">*/
/*                     <h3>Free</h3>*/
/*                     <div class="media-left">*/
/*                         <a href="#alertModal" data-toggle="modal" data-target="#alertModal"><i class="icon-lg ion-ios-cloud-download-outline"></i></a>*/
/*                     </div>*/
/*                     <div class="media-body media-middle">*/
/*                         <p>Yes, please. Grab it for yourself, and make something awesome with this.</p>*/
/*                     </div>*/
/*                 </div>*/
/*                 <hr>*/
/*                 <div class="media wow fadeInRight">*/
/*                     <h3>Unique</h3>*/
/*                     <div class="media-body media-middle">*/
/*                         <p>Because you don't want your Bootstrap site, to look like a Bootstrap site.</p>*/
/*                     </div>*/
/*                     <div class="media-right">*/
/*                         <i class="icon-lg ion-ios-snowy"></i>*/
/*                     </div>*/
/*                 </div>*/
/*                 <hr>*/
/*                 <div class="media wow fadeIn">*/
/*                     <h3>Popular</h3>*/
/*                     <div class="media-left">*/
/*                         <i class="icon-lg ion-ios-heart-outline"></i>*/
/*                     </div>*/
/*                     <div class="media-body media-middle">*/
/*                         <p>There's good reason why Bootstrap is the most used frontend framework in the world.</p>*/
/*                     </div>*/
/*                 </div>*/
/*                 <hr>*/
/*                 <div class="media wow fadeInRight">*/
/*                     <h3>Tested</h3>*/
/*                     <div class="media-body media-middle">*/
/*                         <p>Bootstrap is matured and well-tested. It's a stable codebase that provides consistency.</p>*/
/*                     </div>*/
/*                     <div class="media-right">*/
/*                         <i class="icon-lg ion-ios-flask-outline"></i>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/*     </aside>*/
/*     <section id="last">*/
/*         <div class="container">*/
/*             <div class="row">*/
/*                 <div class="col-lg-8 col-lg-offset-2 text-center">*/
/*                     <h2 class="margin-top-0 wow fadeIn">Get in Touch</h2>*/
/*                     <hr class="primary">*/
/*                     <p>We love feedback. Fill out the form below and we'll get back to you as soon as possible.</p>*/
/*                 </div>*/
/*                 <div class="col-lg-10 col-lg-offset-1 text-center">*/
/*                     <form class="contact-form row">*/
/*                         <div class="col-md-4">*/
/*                             <label></label>*/
/*                             <input type="text" class="form-control" placeholder="Name">*/
/*                         </div>*/
/*                         <div class="col-md-4">*/
/*                             <label></label>*/
/*                             <input type="text" class="form-control" placeholder="Email">*/
/*                         </div>*/
/*                         <div class="col-md-4">*/
/*                             <label></label>*/
/*                             <input type="text" class="form-control" placeholder="Phone">*/
/*                         </div>*/
/*                         <div class="col-md-12">*/
/*                             <label></label>*/
/*                             <textarea class="form-control" rows="9" placeholder="Your message here.."></textarea>*/
/*                         </div>*/
/*                         <div class="col-md-4 col-md-offset-4">*/
/*                             <label></label>*/
/*                             <button type="button" data-toggle="modal" data-target="#alertModal" class="btn btn-primary btn-block btn-lg">Send <i class="ion-android-arrow-forward"></i></button>*/
/*                         </div>*/
/*                     </form>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/*     <footer id="footer">*/
/*         <div class="container-fluid">*/
/*             <div class="row">*/
/*                 <div class="col-xs-6 col-sm-3 column">*/
/*                     <h4>Information</h4>*/
/*                     <ul class="list-unstyled">*/
/*                         <li><a href="">Products</a></li>*/
/*                         <li><a href="">Services</a></li>*/
/*                         <li><a href="">Benefits</a></li>*/
/*                         <li><a href="">Developers</a></li>*/
/*                     </ul>*/
/*                 </div>*/
/*                 <div class="col-xs-6 col-sm-3 column">*/
/*                     <h4>About</h4>*/
/*                     <ul class="list-unstyled">*/
/*                         <li><a href="#">Contact Us</a></li>*/
/*                         <li><a href="#">Delivery Information</a></li>*/
/*                         <li><a href="#">Privacy Policy</a></li>*/
/*                         <li><a href="#">Terms &amp; Conditions</a></li>*/
/*                     </ul>*/
/*                 </div>*/
/*                 <div class="col-xs-12 col-sm-3 column">*/
/*                     <h4>Stay Posted</h4>*/
/*                     <form>*/
/*                         <div class="form-group">*/
/*                             <input type="text" class="form-control" title="No spam, we promise!" placeholder="Tell us your email">*/
/*                         </div>*/
/*                         <div class="form-group">*/
/*                             <button class="btn btn-primary" data-toggle="modal" data-target="#alertModal" type="button">Subscribe for updates</button>*/
/*                         </div>*/
/*                     </form>*/
/*                 </div>*/
/*                 <div class="col-xs-12 col-sm-3 text-right">*/
/*                     <h4>Follow</h4>*/
/*                     <ul class="list-inline">*/
/*                         <li><a rel="nofollow" href="" title="Twitter"><i class="icon-lg ion-social-twitter-outline"></i></a>&nbsp;</li>*/
/*                         <li><a rel="nofollow" href="" title="Facebook"><i class="icon-lg ion-social-facebook-outline"></i></a>&nbsp;</li>*/
/*                         <li><a rel="nofollow" href="" title="Dribble"><i class="icon-lg ion-social-dribbble-outline"></i></a></li>*/
/*                     </ul>*/
/*                 </div>*/
/*             </div>*/
/*             <br/>*/
/*             <span class="pull-right text-muted small"><a href="#">liaros</a> ©2016 Company</span>*/
/*         </div>*/
/*     </footer>*/
/*     <div id="galleryModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">*/
/*         <div class="modal-dialog modal-lg">*/
/*             <div class="modal-content">*/
/*                 <div class="modal-body">*/
/*                     <img src="//placehold.it/1200x700/222?text=..." id="galleryImage" class="img-responsive" />*/
/*                     <p>*/
/*                         <br/>*/
/*                         <button class="btn btn-primary btn-lg center-block" data-dismiss="modal" aria-hidden="true">Close <i class="ion-android-close"></i></button>*/
/*                     </p>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/*     <div id="aboutModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">*/
/*         <div class="modal-dialog">*/
/*             <div class="modal-content">*/
/*                 <div class="modal-body">*/
/*                     <h2 class="text-center">Landing Zero Theme</h2>*/
/*                     <h5 class="text-center">*/
/*                         A free, responsive landing page theme built by BootstrapZero.*/
/*                     </h5>*/
/*                     <p class="text-justify">*/
/*                         This is a single-page Bootstrap template with a sleek dark/grey color scheme, accent color and smooth scrolling.*/
/*                         There are vertical content sections with subtle animations that are activated when scrolled into view using the jQuery WOW plugin. There is also a gallery with modals*/
/*                         that work nicely to showcase your work portfolio. Other features include a contact form, email subscribe form, multi-column footer. Uses Questrial Google Font and Ionicons.*/
/*                     </p>*/
/*                     <p class="text-center"><a href="http://www.bootstrapzero.com">Download at BootstrapZero</a></p>*/
/*                     <br/>*/
/*                     <button class="btn btn-primary btn-lg center-block" data-dismiss="modal" aria-hidden="true"> OK </button>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/*     <div id="alertModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">*/
/*         <div class="modal-dialog modal-sm">*/
/*             <div class="modal-content">*/
/*                 <div class="modal-body">*/
/*                     <h2 class="text-center">Nice Job!</h2>*/
/*                     <p class="text-center">You clicked the button, but it doesn't actually go anywhere because this is only a demo.</p>*/
/*                     <br/>*/
/*                     <button class="btn btn-primary btn-lg center-block" data-dismiss="modal" aria-hidden="true">OK <i class="ion-android-close"></i></button>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/*     <!--scripts loaded here from cdn for performance -->*/
/*     <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>*/
/*     <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>*/
/*     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>*/
/*     <script src="//cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>*/
/*     <script src="{{ asset('js/scripts.js') }}"></script>*/
/* {% endblock %}*/
/* */
/* */
