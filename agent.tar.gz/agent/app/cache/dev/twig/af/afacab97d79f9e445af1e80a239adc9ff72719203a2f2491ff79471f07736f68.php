<?php

/* :blog:comment_form_error.html.twig */
class __TwigTemplate_7f1fcd9a7c51e340ff7054383b3129fbef7273ba00eb9840afb5c87bcc28b373 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":blog:comment_form_error.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a466853205066d132e32a741fd058bcedf47d6889296229b44eaf8dcb11bfb1d = $this->env->getExtension("native_profiler");
        $__internal_a466853205066d132e32a741fd058bcedf47d6889296229b44eaf8dcb11bfb1d->enter($__internal_a466853205066d132e32a741fd058bcedf47d6889296229b44eaf8dcb11bfb1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:comment_form_error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a466853205066d132e32a741fd058bcedf47d6889296229b44eaf8dcb11bfb1d->leave($__internal_a466853205066d132e32a741fd058bcedf47d6889296229b44eaf8dcb11bfb1d_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_4e389d64e9a6c47cf56d412a6383e54a00f23d0c27f153683bf9757b357771b5 = $this->env->getExtension("native_profiler");
        $__internal_4e389d64e9a6c47cf56d412a6383e54a00f23d0c27f153683bf9757b357771b5->enter($__internal_4e389d64e9a6c47cf56d412a6383e54a00f23d0c27f153683bf9757b357771b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "comment_form_error";
        
        $__internal_4e389d64e9a6c47cf56d412a6383e54a00f23d0c27f153683bf9757b357771b5->leave($__internal_4e389d64e9a6c47cf56d412a6383e54a00f23d0c27f153683bf9757b357771b5_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_500d24961ded3dcdd3adaacd339a568601e051c21153b678970305041b443501 = $this->env->getExtension("native_profiler");
        $__internal_500d24961ded3dcdd3adaacd339a568601e051c21153b678970305041b443501->enter($__internal_500d24961ded3dcdd3adaacd339a568601e051c21153b678970305041b443501_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("title.comment_error"), "html", null, true);
        echo "</h1>

    <div class=\"well\">
        ";
        // line 9
        echo twig_include($this->env, $context, "blog/_comment_form.html.twig");
        echo "
    </div>
";
        
        $__internal_500d24961ded3dcdd3adaacd339a568601e051c21153b678970305041b443501->leave($__internal_500d24961ded3dcdd3adaacd339a568601e051c21153b678970305041b443501_prof);

    }

    public function getTemplateName()
    {
        return ":blog:comment_form_error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 9,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body_id 'comment_form_error' %}*/
/* */
/* {% block main %}*/
/*     <h1 class="text-danger">{{ 'title.comment_error'|trans }}</h1>*/
/* */
/*     <div class="well">*/
/*         {{ include('blog/_comment_form.html.twig') }}*/
/*     </div>*/
/* {% endblock %}*/
/* */
