<?php

/* TwigBundle:Exception:error404.html.twig */
class __TwigTemplate_765b846830695b8f8610c8128f5b65b106f60e0d111aa65ca5441ac134872a89 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error404.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bbc7f963ea6ed8c174608ad2c98f3e6d93143f9f6445434f4142ecac10abdc25 = $this->env->getExtension("native_profiler");
        $__internal_bbc7f963ea6ed8c174608ad2c98f3e6d93143f9f6445434f4142ecac10abdc25->enter($__internal_bbc7f963ea6ed8c174608ad2c98f3e6d93143f9f6445434f4142ecac10abdc25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error404.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bbc7f963ea6ed8c174608ad2c98f3e6d93143f9f6445434f4142ecac10abdc25->leave($__internal_bbc7f963ea6ed8c174608ad2c98f3e6d93143f9f6445434f4142ecac10abdc25_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_33e47614de82c32b97118f9d49ab7ece957b5a87bb7a0d1ea661678484791f5f = $this->env->getExtension("native_profiler");
        $__internal_33e47614de82c32b97118f9d49ab7ece957b5a87bb7a0d1ea661678484791f5f->enter($__internal_33e47614de82c32b97118f9d49ab7ece957b5a87bb7a0d1ea661678484791f5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_33e47614de82c32b97118f9d49ab7ece957b5a87bb7a0d1ea661678484791f5f->leave($__internal_33e47614de82c32b97118f9d49ab7ece957b5a87bb7a0d1ea661678484791f5f_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_873e00abc8921c57885814da69911f1ae3dbad06a73f1396ddbfa103a39cd8b5 = $this->env->getExtension("native_profiler");
        $__internal_873e00abc8921c57885814da69911f1ae3dbad06a73f1396ddbfa103a39cd8b5->enter($__internal_873e00abc8921c57885814da69911f1ae3dbad06a73f1396ddbfa103a39cd8b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">Error 404</h1>

    <p class=\"lead\">
        We couldn't find the page you requested.
    </p>
    <p>
        Check out any misspelling in the URL or
        <a href=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("blog_index");
        echo "\">go back to the homepage</a>.
    </p>
";
        
        $__internal_873e00abc8921c57885814da69911f1ae3dbad06a73f1396ddbfa103a39cd8b5->leave($__internal_873e00abc8921c57885814da69911f1ae3dbad06a73f1396ddbfa103a39cd8b5_prof);

    }

    // line 27
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_528e0ae50f708e05b5df84cff917bef50aa2ffb72a6eb73cdbb95f2ac554340c = $this->env->getExtension("native_profiler");
        $__internal_528e0ae50f708e05b5df84cff917bef50aa2ffb72a6eb73cdbb95f2ac554340c->enter($__internal_528e0ae50f708e05b5df84cff917bef50aa2ffb72a6eb73cdbb95f2ac554340c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 28
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 30
        echo $this->env->getExtension('code_explorer_source_code')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_528e0ae50f708e05b5df84cff917bef50aa2ffb72a6eb73cdbb95f2ac554340c->leave($__internal_528e0ae50f708e05b5df84cff917bef50aa2ffb72a6eb73cdbb95f2ac554340c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error404.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 30,  79 => 28,  73 => 27,  63 => 23,  54 => 16,  48 => 15,  36 => 13,  11 => 11,);
    }
}
/* {#*/
/*     This template is used to render errors of type HTTP 404 (Not Found)*/
/* */
/*     This is the simplest way to customize error pages in Symfony applications.*/
/*     In case you need it, you can also hook into the internal exception handling*/
/*     made by Symfony. This allows you to perform advanced tasks and even recover*/
/*     your application from some errors.*/
/*     See http://symfony.com/doc/current/cookbook/controller/error_pages.html*/
/* #}*/
/* */
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body_id 'error' %}*/
/* */
/* {% block main %}*/
/*     <h1 class="text-danger">Error 404</h1>*/
/* */
/*     <p class="lead">*/
/*         We couldn't find the page you requested.*/
/*     </p>*/
/*     <p>*/
/*         Check out any misspelling in the URL or*/
/*         <a href="{{ path('blog_index') }}">go back to the homepage</a>.*/
/*     </p>*/
/* {% endblock %}*/
/* */
/* {% block sidebar %}*/
/*     {{ parent() }}*/
/* */
/*     {{ show_source_code(_self) }}*/
/* {% endblock %}*/
/* */
