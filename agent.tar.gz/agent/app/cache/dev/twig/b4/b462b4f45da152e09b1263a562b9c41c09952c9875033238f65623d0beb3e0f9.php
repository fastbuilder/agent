<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_5aadf4de92fa86a20b49edc18a08d47f51b0c2b359e4de61bc746568a945cec2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de7269b19a80c48af98000b568f6857389cadf0164726cc80bdb129d0be4a025 = $this->env->getExtension("native_profiler");
        $__internal_de7269b19a80c48af98000b568f6857389cadf0164726cc80bdb129d0be4a025->enter($__internal_de7269b19a80c48af98000b568f6857389cadf0164726cc80bdb129d0be4a025_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_de7269b19a80c48af98000b568f6857389cadf0164726cc80bdb129d0be4a025->leave($__internal_de7269b19a80c48af98000b568f6857389cadf0164726cc80bdb129d0be4a025_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:exception.xml.twig' with { 'exception': exception } %}*/
/* */
